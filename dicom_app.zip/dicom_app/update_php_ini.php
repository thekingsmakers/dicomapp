<?php
// Script to update php.ini with correct upload settings
$phpIniPath = 'C:\xampp\php\php.ini';

echo "<h1>PHP.INI Update Script</h1>";

if (!file_exists($phpIniPath)) {
    echo "<p style='color: red;'>❌ PHP.INI file not found at: $phpIniPath</p>";
    exit;
}

echo "<p>Found PHP.INI at: $phpIniPath</p>";

// Read the current php.ini file
$content = file_get_contents($phpIniPath);
if ($content === false) {
    echo "<p style='color: red;'>❌ Failed to read php.ini file</p>";
    exit;
}

echo "<h2>Current Settings:</h2>";
$currentSettings = [
    'upload_max_filesize' => '40M',
    'post_max_size' => '40M',
    'max_execution_time' => '30',
    'max_input_time' => '60',
    'memory_limit' => '128M'
];

foreach ($currentSettings as $setting => $defaultValue) {
    if (preg_match("/^;?\s*$setting\s*=\s*(.+)$/m", $content, $matches)) {
        $currentSettings[$setting] = trim($matches[1]);
    }
}

echo "<ul>";
foreach ($currentSettings as $setting => $value) {
    echo "<li>$setting: $value</li>";
}
echo "</ul>";

// New settings
$newSettings = [
    'upload_max_filesize' => '2G',
    'post_max_size' => '2G',
    'max_execution_time' => '300',
    'max_input_time' => '300',
    'memory_limit' => '512M'
];

echo "<h2>New Settings to Apply:</h2>";
echo "<ul>";
foreach ($newSettings as $setting => $value) {
    echo "<li>$setting: $value</li>";
}
echo "</ul>";

// Update the content
$updated = false;
foreach ($newSettings as $setting => $newValue) {
    $pattern = "/^;?\s*$setting\s*=\s*.+$/m";
    $replacement = "$setting = $newValue";
    
    if (preg_match($pattern, $content)) {
        $content = preg_replace($pattern, $replacement, $content);
        $updated = true;
        echo "<p style='color: green;'>✅ Updated $setting to $newValue</p>";
    } else {
        echo "<p style='color: orange;'>⚠️ Setting $setting not found in php.ini</p>";
    }
}

if ($updated) {
    // Create backup
    $backupPath = $phpIniPath . '.backup.' . date('Y-m-d-H-i-s');
    if (copy($phpIniPath, $backupPath)) {
        echo "<p style='color: green;'>✅ Created backup: $backupPath</p>";
    } else {
        echo "<p style='color: red;'>❌ Failed to create backup</p>";
        exit;
    }
    
    // Write updated content
    if (file_put_contents($phpIniPath, $content)) {
        echo "<p style='color: green;'>✅ Successfully updated php.ini</p>";
        echo "<p><strong>Important:</strong> You need to restart Apache for these changes to take effect.</p>";
        echo "<p>You can restart Apache from XAMPP Control Panel or run: net stop apache2.4 && net start apache2.4</p>";
    } else {
        echo "<p style='color: red;'>❌ Failed to write php.ini file</p>";
    }
} else {
    echo "<p style='color: orange;'>⚠️ No changes were made</p>";
}
?>
