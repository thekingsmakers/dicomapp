    <?php
    $servername = "localhost"; // Or your MySQL server IP/hostname
    $username = "admin"; // Your MySQL username
    $password = "G@ngstar36"; // Your MySQL password
    $dbname = "dicom_app"; // Your MySQL database name

    // Create connection
    $conn = new mysqli($servername, $username, $password, $dbname);

    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }
    echo "Connected successfully to MySQL!";

    // Close connection
    $conn->close();
    ?>