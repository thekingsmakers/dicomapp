<?php
declare(strict_types=1);

require_once __DIR__ . '/config.php';
require_once __DIR__ . '/lib/auth.php';
require_once __DIR__ . '/lib/db.php';

// Simple test without authentication for debugging
echo "<h1>DICOM File Serving Test</h1>";

// Check if we have any DICOM files in the database
$stmt = db()->prepare("SELECT df.id, df.file_path, df.original_filename, p.mrn 
                       FROM dicom_files df 
                       JOIN patients p ON p.id = df.patient_id 
                       LIMIT 5");
$stmt->execute();
$files = $stmt->fetchAll();

if (empty($files)) {
    echo "<p>No DICOM files found in database.</p>";
    echo "<p>Please upload some DICOM files first.</p>";
} else {
    echo "<h2>Available DICOM Files:</h2>";
    echo "<ul>";
    foreach ($files as $file) {
        $filePath = $UPLOAD_DIR . DIRECTORY_SEPARATOR . $file['file_path'];
        $exists = file_exists($filePath) ? '✅' : '❌';
        $size = file_exists($filePath) ? filesize($filePath) : 'N/A';
        
        echo "<li>";
        echo "<strong>ID:</strong> {$file['id']} | ";
        echo "<strong>MRN:</strong> {$file['mrn']} | ";
        echo "<strong>Filename:</strong> {$file['original_filename']} | ";
        echo "<strong>File exists:</strong> {$exists} | ";
        echo "<strong>Size:</strong> " . ($size !== 'N/A' ? number_format($size) . ' bytes' : 'N/A');
        echo "</li>";
        
        // Test the serve URL
        $serveUrl = app_url('serve_dicom.php?id=' . $file['id']);
        echo "<li><strong>Serve URL:</strong> <a href='{$serveUrl}' target='_blank'>{$serveUrl}</a></li>";
    }
    echo "</ul>";
    
    // Test Cornerstone.js integration
    if (!empty($files)) {
        $testFile = $files[0];
        echo "<h2>Cornerstone.js Test</h2>";
        echo "<p>Testing with file ID: {$testFile['id']}</p>";
        echo "<div id='testViewer' style='width: 400px; height: 300px; background: #000; border: 1px solid #ccc;'></div>";
        
        echo "<script src='" . app_url('js/cornerstone/dicomParser.min.js') . "'></script>";
        echo "<script src='" . app_url('js/cornerstone/cornerstone.min.js') . "'></script>";
        echo "<script src='" . app_url('js/cornerstone/cornerstoneMath.min.js') . "'></script>";
        echo "<script src='" . app_url('js/cornerstone/cornerstoneTools.min.js') . "'></script>";
        echo "<script src='" . app_url('js/cornerstone/cornerstoneWADOImageLoader.bundle.min.js') . "'></script>";
        
        echo "<script>";
        echo "cornerstoneWADOImageLoader.external.cornerstone = cornerstone;";
        echo "cornerstoneWADOImageLoader.external.cornerstoneMath = cornerstoneMath;";
        echo "cornerstoneWADOImageLoader.external.dicomParser = dicomParser;";
        echo "cornerstoneWADOImageLoader.webWorkerManager.initialize({";
        echo "    maxWebWorkers: 1,";
        echo "    startWebWorkersOnDemand: true";
        echo "});";
        echo "const element = document.getElementById('testViewer');";
        echo "cornerstone.enable(element);";
        echo "const imageId = 'wadouri:" . app_url('serve_dicom.php?id=' . $testFile['id']) . "';";
        echo "console.log('Testing image ID:', imageId);";
        echo "cornerstone.loadImage(imageId).then(function(image) {";
        echo "    console.log('Test image loaded:', image);";
        echo "    cornerstone.displayImage(element, image);";
        echo "    element.innerHTML += '<div style=\"color: white; text-align: center; padding-top: 10px;\">✅ Loaded successfully</div>';";
        echo "}).catch(function(error) {";
        echo "    console.error('Test error:', error);";
        echo "    element.innerHTML = '<div style=\"color: red; text-align: center; padding-top: 100px;\">❌ Error: ' + error.message + '</div>';";
        echo "});";
        echo "</script>";
    }
}

echo "<h2>System Information</h2>";
echo "<ul>";
echo "<li><strong>Upload Directory:</strong> {$UPLOAD_DIR}</li>";
echo "<li><strong>Upload Directory Writable:</strong> " . (is_writable($UPLOAD_DIR) ? 'Yes' : 'No') . "</li>";
echo "<li><strong>PHP Version:</strong> " . PHP_VERSION . "</li>";
echo "<li><strong>Memory Limit:</strong> " . ini_get('memory_limit') . "</li>";
echo "<li><strong>Max Upload Size:</strong> " . ini_get('upload_max_filesize') . "</li>";
echo "</ul>";
?>
