<?php
// PHP Upload Configuration Override
// This file should be included at the top of upload-related pages

// Note: upload_max_filesize and post_max_size cannot be changed with ini_set()
// They must be set in php.ini or .htaccess file
// These settings can be changed at runtime:
ini_set('max_execution_time', 300);
ini_set('max_input_time', 300);
ini_set('memory_limit', '512M');

// Verify settings were applied
echo "<!-- PHP Upload Settings Applied: -->\n";
echo "<!-- upload_max_filesize: " . ini_get('upload_max_filesize') . " -->\n";
echo "<!-- post_max_size: " . ini_get('post_max_size') . " -->\n";
echo "<!-- max_execution_time: " . ini_get('max_execution_time') . " -->\n";
echo "<!-- memory_limit: " . ini_get('memory_limit') . " -->\n";
?>
