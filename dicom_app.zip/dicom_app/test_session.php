<?php
declare(strict_types=1);

require_once __DIR__ . '/config.php';
require_once __DIR__ . '/lib/auth.php';

echo "<h2>Session and Authentication Test</h2>";

// Test 1: Session functionality
echo "<h3>1. Testing Session Functionality</h3>";
if (session_status() !== PHP_SESSION_ACTIVE) {
    session_start();
    echo "✅ Session started<br>";
} else {
    echo "✅ Session already active<br>";
}

echo "Session ID: " . session_id() . "<br>";
echo "Session name: " . session_name() . "<br>";
echo "Session save path: " . session_save_path() . "<br>";

// Test 2: Current user status
echo "<h3>2. Current User Status</h3>";
$currentUser = current_user();
if ($currentUser) {
    echo "✅ User is logged in:<br>";
    echo "- ID: {$currentUser['id']}<br>";
    echo "- Username: {$currentUser['username']}<br>";
    echo "- Role: {$currentUser['role']}<br>";
} else {
    echo "❌ No user is currently logged in<br>";
}

// Test 3: Session data
echo "<h3>3. Session Data</h3>";
if (!empty($_SESSION)) {
    echo "Session contains data:<br>";
    foreach ($_SESSION as $key => $value) {
        echo "- {$key}: " . (is_array($value) ? json_encode($value) : $value) . "<br>";
    }
} else {
    echo "Session is empty<br>";
}

// Test 4: Test login attempt
echo "<h3>4. Testing Login Attempt</h3>";
if (isset($_GET['test_login'])) {
    $username = $_GET['username'] ?? 'admin';
    $password = $_GET['password'] ?? 'Admin@123';
    
    echo "Attempting login with username: {$username}<br>";
    
    try {
        if (attempt_login($username, $password)) {
            echo "✅ Login successful!<br>";
            $user = current_user();
            if ($user) {
                echo "User data: " . json_encode($user) . "<br>";
            }
        } else {
            echo "❌ Login failed<br>";
        }
    } catch (Exception $e) {
        echo "❌ Login error: " . $e->getMessage() . "<br>";
    }
} else {
    echo "To test login, add ?test_login=1&username=admin&password=Admin@123 to the URL<br>";
}

// Test 5: Database connection test
echo "<h3>5. Database Connection Test</h3>";
try {
    require_once __DIR__ . '/lib/db.php';
    $pdo = db();
    echo "✅ Database connection successful<br>";
    
    // Test user query
    $stmt = $pdo->prepare("SELECT id, username, role FROM users WHERE username = ?");
    $stmt->execute(['admin']);
    $user = $stmt->fetch();
    
    if ($user) {
        echo "✅ Admin user found in database<br>";
    } else {
        echo "❌ Admin user not found in database<br>";
    }
    
} catch (Exception $e) {
    echo "❌ Database error: " . $e->getMessage() . "<br>";
}

echo "<br><h3>Quick Actions:</h3>";
echo "<a href='setup_database.php'>Setup Database</a> | ";
echo "<a href='login.php'>Go to Login</a> | ";
echo "<a href='logout.php'>Logout</a> | ";
echo "<a href='test_session.php?test_login=1&username=admin&password=Admin@123'>Test Login</a>";
?>
