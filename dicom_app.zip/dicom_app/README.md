# DICOM Medical Imaging Management System

A modern, secure web application for managing DICOM medical imaging files with role-based access control.

## 🚀 Features

### Modern UI/UX
- **Responsive Design**: Works perfectly on desktop, tablet, and mobile devices
- **Modern Interface**: Clean, professional design with intuitive navigation
- **Interactive Elements**: Hover effects, animations, and smooth transitions
- **Drag & Drop Upload**: Easy file upload with visual feedback
- **Real-time Search**: Instant filtering and search capabilities

### Role-Based Access Control
- **Admin**: Full system management, user creation, file deletion, study assignment
- **Doctor**: View assigned studies, patient information, medical imaging
- **Uploader**: Upload DICOM files, assign to doctors, manage uploads

### File Management
- **DICOM Validation**: Automatic validation of uploaded files
- **File Organization**: Organized by patient MRN (Medical Record Number)
- **File Deletion**: Admin can delete files with confirmation
- **Study Assignment**: Assign studies to specific doctors
- **File Size Tracking**: Monitor storage usage

### Professional DICOM Viewer
- **Cornerstone.js Integration**: Industry-standard medical imaging viewer
- **Medical Tools**: Window/Level, Zoom, Pan, Length, and Angle measurements
- **DICOM Metadata**: Display patient and study information
- **Responsive Design**: Works on desktop and mobile devices
- **Cross-browser Support**: Compatible with all modern browsers

### Security Features
- **CSRF Protection**: All forms protected against CSRF attacks
- **Session Management**: Secure session handling
- **Input Validation**: Comprehensive input sanitization
- **File Type Validation**: Only DICOM files accepted
- **Role-based Permissions**: Strict access control

## 🛠️ Installation

### Prerequisites
- PHP 8.0 or higher
- MySQL 5.7 or higher / MariaDB 10.2 or higher
- Web server (Apache/Nginx)
- XAMPP/WAMP/MAMP (for local development)

### Setup Instructions

1. **Clone/Download** the application to your web server directory
2. **Configure Database**:
   ```sql
   -- Import the database schema
   mysql -u your_username -p < db.sql
   ```
3. **Configure Application**:
   - Edit `config.php` with your database credentials
   - Update `$APP_BASE_PATH` to match your installation path
   - Ensure upload directory is writable
4. **Set Permissions**:
   ```bash
   chmod 755 uploads/
   chmod 644 *.php
   ```

### Default Credentials
- **Admin**: `admin` / `Admin@123`
- **Doctors/Uploaders**: Create via admin panel

## 📱 User Interface

### Admin Dashboard
- **Statistics Cards**: Overview of system usage
- **User Management**: Create and manage users
- **Study Management**: View, assign, and delete studies
- **File Operations**: Delete files with confirmation dialogs

### Doctor Dashboard
- **My Studies**: View assigned studies
- **Patient Information**: Access patient MRNs
- **Professional DICOM Viewer**: Full-featured medical imaging viewer with tools
- **Search & Filter**: Find specific studies quickly

### Uploader Dashboard
- **Drag & Drop Upload**: Modern file upload interface
- **Batch Upload**: Upload multiple files at once
- **Doctor Assignment**: Assign studies to doctors
- **Upload History**: Track all uploads

### Login Page
- **Modern Design**: Gradient background with card layout
- **Demo Credentials**: Built-in help information
- **Responsive**: Works on all device sizes

## 🎨 Design System

### Color Palette
- **Primary**: Blue (#2563eb)
- **Success**: Green (#10b981)
- **Danger**: Red (#ef4444)
- **Warning**: Orange (#f59e0b)
- **Info**: Blue (#3b82f6)

### Typography
- **Font**: Inter (Google Fonts)
- **Weights**: 400, 500, 600, 700
- **Responsive**: Scales appropriately on all devices

### Components
- **Cards**: Clean, shadowed containers
- **Buttons**: Multiple styles (primary, secondary, danger, etc.)
- **Tables**: Responsive with hover effects
- **Forms**: Modern input styling with validation
- **Alerts**: Color-coded notification system
- **Badges**: Status indicators and labels

## 🔧 Technical Details

### File Structure
```
dicom_app/
├── config.php              # Application configuration
├── css/
│   └── styles.css          # Modern CSS with variables
├── js/
│   └── app.js              # Enhanced JavaScript functionality
├── lib/
│   ├── auth.php            # Authentication system
│   ├── db.php              # Database connection
│   ├── csrf.php            # CSRF protection
│   └── validation.php      # Input validation
├── partials/
│   ├── header.php          # Modern header with navigation
│   └── footer.php          # Footer template
├── uploads/                # DICOM file storage
├── dashboard_admin.php     # Admin dashboard
├── dashboard_doctor.php    # Doctor dashboard
├── dashboard_uploader.php  # Uploader dashboard
├── login.php              # Modern login page
└── view_dicom.php         # DICOM viewer
```

### JavaScript Features
- **Auto-hide Alerts**: Notifications disappear automatically
- **Form Validation**: Client-side validation with visual feedback
- **Delete Confirmations**: Prevents accidental deletions
- **Real-time Search**: Instant table filtering
- **Tooltips**: Enhanced user guidance
- **Loading States**: Visual feedback during operations

### CSS Features
- **CSS Variables**: Consistent theming system
- **Flexbox/Grid**: Modern layout techniques
- **Responsive Design**: Mobile-first approach
- **Animations**: Smooth transitions and hover effects
- **Dark Mode Ready**: CSS variables enable easy theming

## 🔒 Security Considerations

- **CSRF Protection**: All forms protected
- **SQL Injection Prevention**: Prepared statements
- **XSS Prevention**: Output escaping
- **File Upload Security**: Type and size validation
- **Session Security**: Secure cookie settings
- **Input Validation**: Server-side validation

## 🚀 Performance Optimizations

- **Minified CSS/JS**: Optimized for production
- **Image Optimization**: Efficient file handling
- **Database Indexing**: Optimized queries
- **Caching**: Browser caching headers
- **Lazy Loading**: Efficient resource loading

## 📊 System Requirements

### Server
- PHP 8.0+
- MySQL 5.7+ / MariaDB 10.2+
- 100MB+ disk space
- 512MB+ RAM

### Browser Support
- Chrome 90+
- Firefox 88+
- Safari 14+
- Edge 90+

## 🤝 Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Test thoroughly
5. Submit a pull request

## 📄 License

This project is licensed under the MIT License - see the LICENSE file for details.

## 🆘 Support

For support and questions:
- Check the documentation
- Review the code comments
- Create an issue on GitHub

---

**Note**: This is a development system. For production use, ensure proper security hardening, SSL certificates, and regular backups.
