<?php
declare(strict_types=1);

require_once __DIR__ . '/config.php';
require_once __DIR__ . '/lib/auth.php';

logout();
header('Location: ' . app_url('login.php'));
exit;


