-- MySQL schema for dicom_app
SET NAMES utf8mb4;
SET time_zone = '+00:00';

CREATE DATABASE IF NOT EXISTS `dicom_app` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE `dicom_app`;

CREATE TABLE IF NOT EXISTS users (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  username VARCHAR(191) NOT NULL UNIQUE,
  password_hash VARCHAR(255) NOT NULL,
  role ENUM('admin','doctor','uploader') NOT NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS patients (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  mrn VARCHAR(64) NOT NULL UNIQUE,
  name VARCHAR(255) NULL,
  dob DATE NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS dicom_files (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  patient_id INT UNSIGNED NOT NULL,
  file_path VARCHAR(1024) NOT NULL,
  uploaded_by INT UNSIGNED NOT NULL,
  assigned_doctor INT UNSIGNED NULL,
  upload_date DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  original_filename VARCHAR(255) NULL,
  file_size BIGINT NULL,
  modality VARCHAR(32) NULL,
  INDEX (patient_id),
  INDEX (uploaded_by),
  INDEX (assigned_doctor),
  CONSTRAINT fk_dicom_patient FOREIGN KEY (patient_id) REFERENCES patients(id) ON DELETE CASCADE,
  CONSTRAINT fk_dicom_uploaded_by FOREIGN KEY (uploaded_by) REFERENCES users(id) ON DELETE RESTRICT,
  CONSTRAINT fk_dicom_assigned_doctor FOREIGN KEY (assigned_doctor) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Seed admin user (password: Admin@123)
INSERT INTO users (username, password_hash, role) VALUES (
  'admin',
  '$2y$10$Q5wWJzQjmrhZrj6m3e9vIO0z0qZQzXWJm5Kk9oG1JdVQnN2f0c9fO',
  'admin'
) ON DUPLICATE KEY UPDATE username = username;

-- Note: The above hash is a placeholder. Replace with a fresh hash in production.


