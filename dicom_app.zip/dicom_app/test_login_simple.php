<?php
declare(strict_types=1);

require_once __DIR__ . '/config.php';
require_once __DIR__ . '/lib/auth.php';

// Start session
if (session_status() !== PHP_SESSION_ACTIVE) {
    session_start();
}

echo "<h2>Simple Login Test</h2>";

// Handle login attempt
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';
    
    echo "<h3>Login Attempt:</h3>";
    echo "Username: " . htmlspecialchars($username) . "<br>";
    echo "Password provided: " . (empty($password) ? 'NO' : 'YES') . "<br>";
    
    if (empty($username) || empty($password)) {
        echo "<p style='color: red;'>❌ Username or password is empty</p>";
    } else {
        try {
            // Test database connection
            require_once __DIR__ . '/lib/db.php';
            $pdo = db();
            echo "✅ Database connected<br>";
            
            // Check if user exists
            $stmt = $pdo->prepare("SELECT id, username, password_hash, role FROM users WHERE username = ?");
            $stmt->execute([$username]);
            $user = $stmt->fetch();
            
            if ($user) {
                echo "✅ User found in database<br>";
                echo "User ID: " . $user['id'] . "<br>";
                echo "User Role: " . $user['role'] . "<br>";
                
                // Verify password
                if (password_verify($password, $user['password_hash'])) {
                    echo "✅ Password is correct<br>";
                    
                    // Test the attempt_login function
                    if (attempt_login($username, $password)) {
                        echo "✅ Login function successful<br>";
                        
                        // Check current user
                        $currentUser = current_user();
                        if ($currentUser) {
                            echo "✅ Current user set in session<br>";
                            echo "Session user data: " . json_encode($currentUser) . "<br>";
                            
                            // Test redirect
                            $dashboard_url = 'dashboard_' . $currentUser['role'] . '.php';
                            echo "Dashboard URL: " . $dashboard_url . "<br>";
                            
                            if (file_exists($dashboard_url)) {
                                echo "✅ Dashboard file exists<br>";
                                echo "<p style='color: green; font-weight: bold;'>🎉 LOGIN SUCCESSFUL!</p>";
                                echo "<p><a href='{$dashboard_url}' style='background: green; color: white; padding: 10px; text-decoration: none;'>Click here to go to dashboard</a></p>";
                                
                                // Try automatic redirect
                                echo "<script>setTimeout(function(){ window.location.href = '{$dashboard_url}'; }, 2000);</script>";
                                echo "<p>Redirecting automatically in 2 seconds...</p>";
                            } else {
                                echo "❌ Dashboard file not found: " . $dashboard_url . "<br>";
                            }
                        } else {
                            echo "❌ Current user not set in session<br>";
                        }
                    } else {
                        echo "❌ Login function failed<br>";
                    }
                } else {
                    echo "❌ Password is incorrect<br>";
                    echo "Password hash in DB: " . substr($user['password_hash'], 0, 20) . "...<br>";
                }
            } else {
                echo "❌ User not found in database<br>";
            }
            
        } catch (Exception $e) {
            echo "❌ Error: " . $e->getMessage() . "<br>";
        }
    }
}

echo "<h3>Current Session Info:</h3>";
echo "Session ID: " . session_id() . "<br>";
echo "Session status: " . session_status() . "<br>";

$currentUser = current_user();
if ($currentUser) {
    echo "✅ Already logged in as: " . $currentUser['username'] . " (Role: " . $currentUser['role'] . ")<br>";
    echo "<a href='dashboard_{$currentUser['role']}.php'>Go to Dashboard</a> | <a href='logout.php'>Logout</a><br>";
} else {
    echo "❌ Not logged in<br>";
}

echo "<h3>Test Login Form:</h3>";
?>
<form method="POST" style="border: 1px solid #ccc; padding: 20px; margin: 20px 0;">
    <div>
        <label>Username: <input type="text" name="username" value="admin" required></label>
    </div>
    <div>
        <label>Password: <input type="password" name="password" value="Admin@123" required></label>
    </div>
    <div>
        <button type="submit">Test Login</button>
    </div>
</form>

<p><a href="setup_database.php">Setup Database</a> | <a href="login.php">Main Login</a></p>
