<?php
declare(strict_types=1);

// Application configuration

// Base URL of the app (adjust to your environment), e.g., '/dicom_app'
$APP_BASE_PATH = '/dicom_app';

// Upload directory (relative to this file's directory)
$UPLOAD_DIR = __DIR__ . DIRECTORY_SEPARATOR . 'uploads';

// Max upload size in bytes (2GB)
$MAX_UPLOAD_BYTES = 2 * 1024 * 1024 * 1024;

// Database configuration
$DB_DSN = getenv('DICOM_APP_DB_DSN') ?: 'mysql:host=localhost;port=3306;dbname=dicom_app;charset=utf8mb4';
$DB_USER = getenv('DICOM_APP_DB_USER') ?: 'admin';
$DB_PASS = getenv('DICOM_APP_DB_PASS') ?: 'G@ngstar36';

// Session cookie settings
$IS_HTTPS = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') || (isset($_SERVER['SERVER_PORT']) && (int)$_SERVER['SERVER_PORT'] === 443);

// For XAMPP development, use more permissive session settings
session_set_cookie_params([
    'lifetime' => 0,
    'path' => '/', // Use root path for better compatibility
    'domain' => '',
    'secure' => false, // Set to false for HTTP development
    'httponly' => true,
    'samesite' => 'Lax', // Use Lax instead of Strict for better compatibility
]);

// Content Security Policy headers (can be refined)
function send_security_headers(): void
{
    header('X-Frame-Options: DENY');
    header('X-Content-Type-Options: nosniff');
    header('Referrer-Policy: no-referrer');
    // Allow self and CDN for Cornerstone (adjust if you self-host assets)
    $csp = "default-src 'self'; script-src 'self' 'unsafe-inline' 'unsafe-eval' https://unpkg.com https://cdn.jsdelivr.net; style-src 'self' 'unsafe-inline' https://fonts.googleapis.com https://cdnjs.cloudflare.com https://unpkg.com https://cdn.jsdelivr.net; font-src 'self' https://fonts.gstatic.com https://cdnjs.cloudflare.com; img-src 'self' data: blob:; connect-src 'self' blob: data:; frame-ancestors 'none'; worker-src 'self' blob: data:; object-src 'none';";
    header('Content-Security-Policy: ' . $csp);
}

// Ensure uploads dir exists
if (!is_dir($UPLOAD_DIR)) {
    @mkdir($UPLOAD_DIR, 0775, true);
}

// Utility for building absolute URLs within the app
function app_url(string $path = ''): string
{
    global $APP_BASE_PATH;
    $base = rtrim($APP_BASE_PATH, '/');
    $path = '/' . ltrim($path, '/');
    return $base . $path;
}


