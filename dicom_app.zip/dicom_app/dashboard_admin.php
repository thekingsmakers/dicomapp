<?php
declare(strict_types=1);

require_once __DIR__ . '/config.php';
require_once __DIR__ . '/lib/auth.php';
require_once __DIR__ . '/lib/db.php';
require_once __DIR__ . '/lib/csrf.php';

require_role('admin');

$message = '';
$error = '';

// Handle create user
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'create_user') {
    verify_csrf_token();
    $username = trim($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';
    $role = $_POST['role'] ?? '';
    if ($username && $password && in_array($role, ['doctor','uploader','admin'], true)) {
        try {
            $sql = 'INSERT INTO users (username, password_hash, role) VALUES (?, ?, ?)';
            db()->prepare($sql)->execute([$username, password_hash($password, PASSWORD_DEFAULT), $role]);
            $message = 'User created successfully';
        } catch (Throwable $e) {
            $error = 'Failed to create user: ' . $e->getMessage();
        }
    } else {
        $error = 'Invalid user data';
    }
}

// Handle reassign study
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'reassign') {
    verify_csrf_token();
    $dicomId = (int)($_POST['dicom_id'] ?? 0);
    $doctorId = (int)($_POST['doctor_id'] ?? 0);
    if ($dicomId > 0 && $doctorId > 0) {
        $sql = 'UPDATE dicom_files SET assigned_doctor = ? WHERE id = ?';
        db()->prepare($sql)->execute([$doctorId, $dicomId]);
        $message = 'Study reassigned successfully';
    } else {
        $error = 'Invalid reassignment data';
    }
}

// Handle delete file
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'delete_file') {
    verify_csrf_token();
    $dicomId = (int)($_POST['dicom_id'] ?? 0);
    if ($dicomId > 0) {
        try {
            // Get file path before deletion
            $stmt = db()->prepare('SELECT file_path FROM dicom_files WHERE id = ?');
            $stmt->execute([$dicomId]);
            $file = $stmt->fetch();
            
            if ($file) {
                // Delete from database
                $stmt = db()->prepare('DELETE FROM dicom_files WHERE id = ?');
                $stmt->execute([$dicomId]);
                
                // Delete physical file
                $filePath = $UPLOAD_DIR . DIRECTORY_SEPARATOR . $file['file_path'];
                if (file_exists($filePath)) {
                    @unlink($filePath);
                }
                
                $message = 'File deleted successfully';
            } else {
                $error = 'File not found';
            }
        } catch (Throwable $e) {
            $error = 'Failed to delete file: ' . $e->getMessage();
        }
    } else {
        $error = 'Invalid file ID';
    }
}

// Handle password reset
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'reset_password') {
    verify_csrf_token();
    $userId = (int)($_POST['user_id'] ?? 0);
    $newPassword = $_POST['new_password'] ?? '';
    
    if ($userId > 0 && !empty($newPassword)) {
        try {
            // Check if user exists
            $stmt = db()->prepare('SELECT username FROM users WHERE id = ?');
            $stmt->execute([$userId]);
            $user = $stmt->fetch();
            
            if ($user) {
                // Update password
                $sql = 'UPDATE users SET password_hash = ? WHERE id = ?';
                db()->prepare($sql)->execute([password_hash($newPassword, PASSWORD_DEFAULT), $userId]);
                $message = 'Password reset successfully for user: ' . htmlspecialchars($user['username']);
            } else {
                $error = 'User not found';
            }
        } catch (Throwable $e) {
            $error = 'Failed to reset password: ' . $e->getMessage();
        }
    } else {
        $error = 'Invalid password reset data';
    }
}

// Fetch statistics
$stats = [
    'total_users' => db()->query('SELECT COUNT(*) FROM users')->fetchColumn(),
    'total_doctors' => db()->query("SELECT COUNT(*) FROM users WHERE role = 'doctor'")->fetchColumn(),
    'total_uploaders' => db()->query("SELECT COUNT(*) FROM users WHERE role = 'uploader'")->fetchColumn(),
    'total_studies' => db()->query('SELECT COUNT(*) FROM dicom_files')->fetchColumn(),
    'total_patients' => db()->query('SELECT COUNT(*) FROM patients')->fetchColumn(),
    'unassigned_studies' => db()->query('SELECT COUNT(*) FROM dicom_files WHERE assigned_doctor IS NULL')->fetchColumn()
];

// Fetch users and studies
$users = db()->query("SELECT id, username, role, created_at FROM users ORDER BY role, username")->fetchAll();
$doctors = array_values(array_filter($users, fn($u) => $u['role'] === 'doctor'));

$where = [];
$params = [];
if (!empty($_GET['mrn'])) { $where[] = 'p.mrn LIKE ?'; $params[] = '%' . $_GET['mrn'] . '%'; }
if (!empty($_GET['doctor_id'])) { $where[] = 'df.assigned_doctor = ?'; $params[] = (int)$_GET['doctor_id']; }
$whereSql = $where ? ('WHERE ' . implode(' AND ', $where)) : '';

$stmt = db()->prepare("SELECT df.id, df.file_path, df.upload_date, df.assigned_doctor, df.original_filename, df.file_size, u.username AS doctor_name, p.mrn
FROM dicom_files df
JOIN patients p ON p.id = df.patient_id
LEFT JOIN users u ON u.id = df.assigned_doctor
$whereSql
ORDER BY df.upload_date DESC LIMIT 500");
$stmt->execute($params);
$studies = $stmt->fetchAll();

include __DIR__ . '/partials/header.php';
?>

<div class="dashboard-header">
    <h1><i class="fas fa-user-shield"></i> Admin Dashboard</h1>
    <p>Manage users, studies, and system settings</p>
</div>

<?php if ($message): ?>
    <div class="alert alert-ok">
        <i class="fas fa-check-circle"></i>
        <?= htmlspecialchars($message) ?>
    </div>
<?php endif; ?>

<?php if ($error): ?>
    <div class="alert alert-error">
        <i class="fas fa-exclamation-circle"></i>
        <?= htmlspecialchars($error) ?>
    </div>
<?php endif; ?>

<!-- Statistics Cards -->
<div class="dashboard-stats">
    <div class="stat-card">
        <div class="stat-number"><?= number_format($stats['total_users']) ?></div>
        <div class="stat-label">Total Users</div>
    </div>
    <div class="stat-card">
        <div class="stat-number"><?= number_format($stats['total_doctors']) ?></div>
        <div class="stat-label">Doctors</div>
    </div>
    <div class="stat-card">
        <div class="stat-number"><?= number_format($stats['total_studies']) ?></div>
        <div class="stat-label">Total Studies</div>
    </div>
    <div class="stat-card">
        <div class="stat-number"><?= number_format($stats['total_patients']) ?></div>
        <div class="stat-label">Patients</div>
    </div>
    <div class="stat-card">
        <div class="stat-number"><?= number_format($stats['unassigned_studies']) ?></div>
        <div class="stat-label">Unassigned Studies</div>
    </div>
</div>

<!-- Create User Section -->
<div class="card">
    <div class="card-header">
        <h2><i class="fas fa-user-plus"></i> Create New User</h2>
    </div>
    <div class="card-body">
        <form method="post" class="form-grid">
        <?= csrf_field() ?>
        <input type="hidden" name="action" value="create_user">
            
            <div class="form-row">
                <label for="username">Username</label>
                <input type="text" id="username" name="username" required>
            </div>
            
            <div class="form-row">
                <label for="password">Password</label>
                <input type="password" id="password" name="password" required>
            </div>
            
            <div class="form-row">
                <label for="role">Role</label>
                <select id="role" name="role" required>
                    <option value="">Select role</option>
                <option value="doctor">Doctor</option>
                <option value="uploader">Uploader</option>
                <option value="admin">Admin</option>
            </select>
            </div>
            
            <div class="form-row">
                <button type="submit" class="btn btn-primary">
                    <i class="fas fa-plus"></i> Create User
                </button>
            </div>
    </form>
    </div>
</div>

<!-- Studies Management Section -->
<div class="card">
    <div class="card-header">
        <h2><i class="fas fa-file-medical"></i> Studies Management</h2>
    </div>
    <div class="card-body">
        <!-- Filters -->
        <div class="filters">
            <h3><i class="fas fa-filter"></i> Filter Studies</h3>
            <form method="get" class="filters-grid">
                <div class="form-row">
                    <label for="mrn">Patient MRN</label>
                    <input type="text" id="mrn" name="mrn" value="<?= htmlspecialchars($_GET['mrn'] ?? '') ?>" placeholder="Search by MRN">
                </div>
                
                <div class="form-row">
                    <label for="doctor_id">Assigned Doctor</label>
                    <select id="doctor_id" name="doctor_id">
                        <option value="">All Doctors</option>
                <?php foreach ($doctors as $d): ?>
                    <option value="<?= (int)$d['id'] ?>" <?= (isset($_GET['doctor_id']) && (int)$_GET['doctor_id'] === (int)$d['id']) ? 'selected' : '' ?>>
                        <?= htmlspecialchars($d['username']) ?>
                    </option>
                <?php endforeach; ?>
            </select>
                </div>
                
                <div class="filters-actions">
                    <button type="submit" class="btn btn-primary">
                        <i class="fas fa-search"></i> Filter
                    </button>
                    <a href="<?= htmlspecialchars(app_url('dashboard_admin.php')) ?>" class="btn btn-secondary">
                        <i class="fas fa-times"></i> Clear
                    </a>
                </div>
    </form>
        </div>

        <!-- Studies Table -->
        <div class="table-container">
    <table class="table">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Patient MRN</th>
                        <th>Filename</th>
                        <th>File Size</th>
                        <th>Upload Date</th>
                        <th>Assigned Doctor</th>
                        <th>Actions</th>
                    </tr>
                </thead>
        <tbody>
                <?php if (empty($studies)): ?>
                    <tr>
                        <td colspan="7" class="empty-state">
                            <div class="empty-state-icon">📁</div>
                            <h3>No studies found</h3>
                            <p>No studies match your current filters.</p>
                        </td>
                    </tr>
                <?php else: ?>
        <?php foreach ($studies as $s): ?>
            <tr>
                            <td><strong>#<?= (int)$s['id'] ?></strong></td>
                            <td>
                                <span class="badge badge-info"><?= htmlspecialchars($s['mrn']) ?></span>
                            </td>
                            <td><?= htmlspecialchars($s['original_filename'] ?? 'Unknown') ?></td>
                            <td><?= $s['file_size'] ? formatBytes($s['file_size']) : '—' ?></td>
                            <td><?= date('M j, Y g:i A', strtotime($s['upload_date'])) ?></td>
                            <td>
                                <?php if ($s['doctor_name']): ?>
                                    <span class="badge badge-success"><?= htmlspecialchars($s['doctor_name']) ?></span>
                                <?php else: ?>
                                    <span class="badge badge-warning">Unassigned</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <div class="actions">
                                    <!-- View Study Button -->
                                    <a href="<?= htmlspecialchars(app_url('view_dicom.php?id=' . (int)$s['id'])) ?>" class="btn btn-sm btn-primary" title="View Study">
                                        <i class="fas fa-eye"></i> View
                                    </a>
                                    
                                    <!-- Reassign Study Button -->
                                    <button type="button" class="btn btn-sm btn-success" title="Reassign Study" onclick="showReassignModal(<?= (int)$s['id'] ?>, '<?= htmlspecialchars($s['mrn']) ?>', <?= (int)($s['assigned_doctor'] ?? 0) ?>)">
                                        <i class="fas fa-user-plus"></i> Assign
                                    </button>
                                    
                                    <!-- Delete Study Button -->
                                    <form method="post" style="display: inline;" onsubmit="return confirm('Are you sure you want to delete this file? This action cannot be undone.')">
                        <?= csrf_field() ?>
                                        <input type="hidden" name="action" value="delete_file">
                        <input type="hidden" name="dicom_id" value="<?= (int)$s['id'] ?>">
                                        <button type="submit" class="btn btn-sm btn-danger" title="Delete Study">
                                            <i class="fas fa-trash"></i> Delete
                                        </button>
                                    </form>
                                </div>
                            </td>
                        </tr>
                            <?php endforeach; ?>
                <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- Users List Section -->
<div class="card">
    <div class="card-header">
        <h2><i class="fas fa-users"></i> System Users</h2>
    </div>
    <div class="card-body">
        <div class="table-container">
            <table class="table">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Username</th>
                        <th>Role</th>
                        <th>Created</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                <?php foreach ($users as $u): ?>
                    <tr>
                        <td><strong>#<?= (int)$u['id'] ?></strong></td>
                        <td><?= htmlspecialchars($u['username']) ?></td>
                        <td>
                            <?php
                            $roleColors = [
                                'admin' => 'badge-danger',
                                'doctor' => 'badge-success',
                                'uploader' => 'badge-info'
                            ];
                            $roleColor = $roleColors[$u['role']] ?? 'badge-secondary';
                            ?>
                            <span class="badge <?= $roleColor ?>"><?= htmlspecialchars(ucfirst($u['role'])) ?></span>
                        </td>
                        <td><?= date('M j, Y', strtotime($u['created_at'])) ?></td>
                        <td>
                            <div class="actions">
                                <button type="button" class="btn btn-sm btn-warning" title="Reset Password" onclick="showPasswordResetModal(<?= (int)$u['id'] ?>, '<?= htmlspecialchars($u['username']) ?>')">
                                    <i class="fas fa-key"></i> Reset Password
                                </button>
                            </div>
                </td>
            </tr>
        <?php endforeach; ?>
        </tbody>
    </table>
        </div>
    </div>
</div>

<?php
function formatBytes($bytes, $precision = 2) {
    $units = array('B', 'KB', 'MB', 'GB', 'TB');
    for ($i = 0; $bytes > 1024 && $i < count($units) - 1; $i++) {
        $bytes /= 1024;
    }
    return round($bytes, $precision) . ' ' . $units[$i];
}
?>

<!-- Reassign Study Modal -->
<div id="reassignModal" class="modal">
    <div class="modal-content">
        <div class="modal-header">
            <h3 class="modal-title">Reassign Study</h3>
            <button type="button" class="close" onclick="closeReassignModal()">&times;</button>
        </div>
        <form method="post" id="reassignForm">
            <?= csrf_field() ?>
            <input type="hidden" name="action" value="reassign">
            <input type="hidden" name="dicom_id" id="modalDicomId">
            
            <div class="form-row">
                <label>Study Information</label>
                <div style="background: #f8fafc; padding: 1rem; border-radius: var(--radius-sm); margin-bottom: 1rem;">
                    <strong>Patient MRN:</strong> <span id="modalMrn"></span><br>
                    <strong>Study ID:</strong> <span id="modalStudyId"></span>
                </div>
            </div>
            
            <div class="form-row">
                <label for="modalDoctorId">Assign to Doctor</label>
                <select id="modalDoctorId" name="doctor_id" required>
                    <option value="">Select a doctor</option>
                    <?php foreach ($doctors as $d): ?>
                        <option value="<?= (int)$d['id'] ?>"><?= htmlspecialchars($d['username']) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            
            <div class="form-row" style="margin-top: 1.5rem;">
                <button type="submit" class="btn btn-success">
                    <i class="fas fa-user-plus"></i> Assign Study
                </button>
                <button type="button" class="btn btn-secondary" onclick="closeReassignModal()" style="margin-left: 0.5rem;">
                    Cancel
                </button>
            </div>
        </form>
    </div>
</div>

<!-- Password Reset Modal -->
<div id="passwordResetModal" class="modal">
    <div class="modal-content">
        <div class="modal-header">
            <h3 class="modal-title">Reset User Password</h3>
            <button type="button" class="close" onclick="closePasswordResetModal()">&times;</button>
        </div>
        <form method="post" id="passwordResetForm">
            <?= csrf_field() ?>
            <input type="hidden" name="action" value="reset_password">
            <input type="hidden" name="user_id" id="modalUserId">
            
            <div class="form-row">
                <label>User Information</label>
                <div style="background: #f8fafc; padding: 1rem; border-radius: var(--radius-sm); margin-bottom: 1rem;">
                    <strong>Username:</strong> <span id="modalUsername"></span><br>
                    <strong>User ID:</strong> <span id="modalUserIdDisplay"></span>
                </div>
            </div>
            
            <div class="form-row">
                <label for="modalNewPassword">New Password</label>
                <input type="password" id="modalNewPassword" name="new_password" required minlength="6" placeholder="Enter new password">
                <small>Minimum 6 characters</small>
            </div>
            
            <div class="form-row">
                <label for="modalConfirmPassword">Confirm Password</label>
                <input type="password" id="modalConfirmPassword" required minlength="6" placeholder="Confirm new password">
                <small>Must match the new password</small>
            </div>
            
            <div class="form-row" style="margin-top: 1.5rem;">
                <button type="submit" class="btn btn-warning">
                    <i class="fas fa-key"></i> Reset Password
                </button>
                <button type="button" class="btn btn-secondary" onclick="closePasswordResetModal()" style="margin-left: 0.5rem;">
                    Cancel
                </button>
            </div>
        </form>
    </div>
</div>

<script>
// Reassign Study Modal Functions
function showReassignModal(dicomId, mrn, currentDoctorId) {
    document.getElementById('modalDicomId').value = dicomId;
    document.getElementById('modalMrn').textContent = mrn;
    document.getElementById('modalStudyId').textContent = '#' + dicomId;
    
    // Set current doctor as selected if exists
    const doctorSelect = document.getElementById('modalDoctorId');
    doctorSelect.value = currentDoctorId || '';
    
    document.getElementById('reassignModal').style.display = 'block';
}

function closeReassignModal() {
    document.getElementById('reassignModal').style.display = 'none';
}

// Password Reset Modal Functions
function showPasswordResetModal(userId, username) {
    document.getElementById('modalUserId').value = userId;
    document.getElementById('modalUsername').textContent = username;
    document.getElementById('modalUserIdDisplay').textContent = '#' + userId;
    
    // Clear previous values
    document.getElementById('modalNewPassword').value = '';
    document.getElementById('modalConfirmPassword').value = '';
    
    document.getElementById('passwordResetModal').style.display = 'block';
}

function closePasswordResetModal() {
    document.getElementById('passwordResetModal').style.display = 'none';
}

// Form validation for password reset
document.getElementById('passwordResetForm').addEventListener('submit', function(e) {
    const newPassword = document.getElementById('modalNewPassword').value;
    const confirmPassword = document.getElementById('modalConfirmPassword').value;
    
    if (newPassword !== confirmPassword) {
        e.preventDefault();
        alert('Passwords do not match!');
        return false;
    }
    
    if (newPassword.length < 6) {
        e.preventDefault();
        alert('Password must be at least 6 characters long!');
        return false;
    }
});

// Close modals when clicking outside
window.onclick = function(event) {
    const reassignModal = document.getElementById('reassignModal');
    const passwordResetModal = document.getElementById('passwordResetModal');
    
    if (event.target === reassignModal) {
        closeReassignModal();
    }
    
    if (event.target === passwordResetModal) {
        closePasswordResetModal();
    }
}
</script>

<?php include __DIR__ . '/partials/footer.php'; ?>

