<?php
declare(strict_types=1);

require_once __DIR__ . '/config.php';
require_once __DIR__ . '/lib/auth.php';
require_once __DIR__ . '/lib/csrf.php';

echo "<h2>Login Process Debug</h2>";

// Start session
if (session_status() !== PHP_SESSION_ACTIVE) {
    session_start();
}

echo "<h3>Step 1: Session Status</h3>";
echo "Session ID: " . session_id() . "<br>";
echo "Session status: " . session_status() . "<br>";

echo "<h3>Step 2: POST Data</h3>";
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    echo "POST method detected<br>";
    echo "Username: " . htmlspecialchars($_POST['username'] ?? 'NOT SET') . "<br>";
    echo "Password: " . (isset($_POST['password']) ? 'SET' : 'NOT SET') . "<br>";
    echo "CSRF Token: " . htmlspecialchars($_POST['csrf_token'] ?? 'NOT SET') . "<br>";
} else {
    echo "No POST data<br>";
}

echo "<h3>Step 3: CSRF Token Check</h3>";
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        verify_csrf_token();
        echo "✅ CSRF token is valid<br>";
    } catch (Exception $e) {
        echo "❌ CSRF token error: " . $e->getMessage() . "<br>";
    }
}

echo "<h3>Step 4: Authentication Test</h3>";
if ($_SERVER['REQUEST_METHOD'] === 'POST' && !empty($_POST['username']) && !empty($_POST['password'])) {
    $username = trim($_POST['username']);
    $password = $_POST['password'];
    
    echo "Attempting login with username: " . htmlspecialchars($username) . "<br>";
    
    try {
        // Test database connection first
        require_once __DIR__ . '/lib/db.php';
        $pdo = db();
        echo "✅ Database connection successful<br>";
        
        // Check if user exists
        $stmt = $pdo->prepare("SELECT id, username, password_hash, role FROM users WHERE username = ?");
        $stmt->execute([$username]);
        $user = $stmt->fetch();
        
        if ($user) {
            echo "✅ User found in database<br>";
            echo "User ID: " . $user['id'] . "<br>";
            echo "User Role: " . $user['role'] . "<br>";
            
            // Test password verification
            if (password_verify($password, $user['password_hash'])) {
                echo "✅ Password is correct<br>";
                
                // Test the actual login function
                if (attempt_login($username, $password)) {
                    echo "✅ Login function successful<br>";
                    
                    // Check current user
                    $currentUser = current_user();
                    if ($currentUser) {
                        echo "✅ Current user set in session<br>";
                        echo "Session user data: " . json_encode($currentUser) . "<br>";
                        
                        // Test redirect URL
                        $dashboard_url = 'dashboard_' . $currentUser['role'] . '.php';
                        echo "Dashboard URL would be: " . $dashboard_url . "<br>";
                        
                        if (file_exists($dashboard_url)) {
                            echo "✅ Dashboard file exists<br>";
                            echo "<strong>REDIRECT SHOULD HAPPEN NOW</strong><br>";
                            echo "<a href='{$dashboard_url}'>Click here to go to dashboard</a><br>";
                        } else {
                            echo "❌ Dashboard file does not exist: " . $dashboard_url . "<br>";
                        }
                    } else {
                        echo "❌ Current user not set in session<br>";
                    }
                } else {
                    echo "❌ Login function failed<br>";
                }
            } else {
                echo "❌ Password is incorrect<br>";
                echo "Password hash in DB: " . substr($user['password_hash'], 0, 20) . "...<br>";
            }
        } else {
            echo "❌ User not found in database<br>";
        }
        
    } catch (Exception $e) {
        echo "❌ Error during authentication: " . $e->getMessage() . "<br>";
    }
}

echo "<h3>Step 5: Current Session Data</h3>";
if (!empty($_SESSION)) {
    foreach ($_SESSION as $key => $value) {
        echo "- {$key}: " . (is_array($value) ? json_encode($value) : $value) . "<br>";
    }
} else {
    echo "Session is empty<br>";
}

echo "<h3>Step 6: Test Login Form</h3>";
?>
<form method="POST" style="border: 1px solid #ccc; padding: 20px; margin: 20px 0;">
    <h4>Test Login</h4>
    <?= csrf_field() ?>
    <div>
        <label>Username: <input type="text" name="username" value="admin"></label>
    </div>
    <div>
        <label>Password: <input type="password" name="password" value="Admin@123"></label>
    </div>
    <div>
        <button type="submit">Test Login</button>
    </div>
</form>

<p><a href="login.php">Go back to main login page</a></p>
