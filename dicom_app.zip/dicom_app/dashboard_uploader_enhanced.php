<?php
declare(strict_types=1);

// Include upload configuration override
require_once __DIR__ . '/php_upload_config.php';

require_once __DIR__ . '/config.php';
require_once __DIR__ . '/lib/auth.php';
require_once __DIR__ . '/lib/db.php';
require_once __DIR__ . '/lib/validation.php';
require_once __DIR__ . '/lib/csrf.php';

require_role('uploader');
global $UPLOAD_DIR, $MAX_UPLOAD_BYTES;

$user = current_user();
$message = '';
$error = '';
$uploadResults = [];

// Fetch doctors for dropdown
$doctors = db()->query("SELECT id, username FROM users WHERE role = 'doctor' ORDER BY username")->fetchAll();

if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'upload') {
    verify_csrf_token();
    $mrn = trim($_POST['mrn'] ?? '');
    $doctorId = (int)($_POST['doctor_id'] ?? 0);

    if (!validate_mrn($mrn)) {
        $error = 'Invalid MRN format';
    } elseif ($doctorId <= 0) {
        $error = 'Please select a doctor';
    } elseif (empty($_FILES['files']) || empty($_FILES['files']['name'][0])) {
        $error = 'No files uploaded. Please select at least one DICOM file.';
    } else {
        // Enhanced batch validation
        $validationErrors = validateUploadBatch($_FILES['files']);
        if (!empty($validationErrors)) {
            $error = 'Upload validation failed: ' . implode(', ', $validationErrors);
        } else {
            $patientId = ensure_patient($mrn);
            $uploadResults = processFileUpload($_FILES['files'], $patientId, $doctorId, $user['id']);
            
            if ($uploadResults['success_count'] > 0) {
                $message = $uploadResults['success_count'] . ' file(s) uploaded successfully';
                if ($uploadResults['failed_count'] > 0) {
                    $message .= ' (' . $uploadResults['failed_count'] . ' files failed)';
                }
            } else {
                $error = 'No files were uploaded successfully. ' . implode(', ', $uploadResults['errors']);
            }
        }
    }
}

/**
 * Enhanced batch validation for multiple files
 */
function validateUploadBatch(array $files): array
{
    global $MAX_UPLOAD_BYTES;
    $errors = [];
    $totalSize = 0;
    $fileCount = count($files['tmp_name']);
    
    // Check total number of files
    if ($fileCount > 50) {
        $errors[] = 'Maximum 50 files allowed per upload';
    }
    
    foreach ($files['tmp_name'] as $idx => $tmp) {
        $name = $files['name'][$idx] ?? '';
        $size = (int)($files['size'][$idx] ?? 0);
        $errorCode = (int)($files['error'][$idx] ?? UPLOAD_ERR_NO_FILE);
        
        // Check individual file errors
        if ($errorCode !== UPLOAD_ERR_OK) {
            $errorMessages = [
                UPLOAD_ERR_INI_SIZE => 'File exceeds PHP upload_max_filesize',
                UPLOAD_ERR_FORM_SIZE => 'File exceeds MAX_FILE_SIZE',
                UPLOAD_ERR_PARTIAL => 'File was only partially uploaded',
                UPLOAD_ERR_NO_FILE => 'No file was uploaded',
                UPLOAD_ERR_NO_TMP_DIR => 'Missing temporary folder',
                UPLOAD_ERR_CANT_WRITE => 'Failed to write file to disk',
                UPLOAD_ERR_EXTENSION => 'A PHP extension stopped the file upload'
            ];
            $errorMsg = $errorMessages[$errorCode] ?? 'Unknown upload error';
            $errors[] = "File '$name': $errorMsg";
            continue;
        }
        
        // Check file size
        if ($size <= 0) {
            $errors[] = "File '$name': Invalid size (0 bytes)";
            continue;
        }
        
        if ($size > $MAX_UPLOAD_BYTES) {
            $errors[] = "File '$name': Exceeds maximum size limit (" . formatBytes($MAX_UPLOAD_BYTES) . ")";
            continue;
        }
        
        // Check file extension
        if (!preg_match('/\.dcm$/i', $name)) {
            $errors[] = "File '$name': Not a DICOM file (.dcm extension required)";
            continue;
        }
        
        $totalSize += $size;
    }
    
    // Check total upload size (limit to 10GB total)
    if ($totalSize > 10 * 1024 * 1024 * 1024) {
        $errors[] = 'Total upload size exceeds 10GB limit';
    }
    
    return $errors;
}

/**
 * Enhanced file processing with better error handling
 */
function processFileUpload(array $files, int $patientId, int $doctorId, int $uploaderId): array
{
    global $UPLOAD_DIR;
    
    $results = [
        'success_count' => 0,
        'failed_count' => 0,
        'errors' => [],
        'successful_files' => [],
        'failed_files' => []
    ];
    
    // Get patient MRN for directory creation
    $stmt = db()->prepare('SELECT mrn FROM patients WHERE id = ?');
    $stmt->execute([$patientId]);
    $patient = $stmt->fetch();
    $mrn = $patient['mrn'];
    
    $mrnDir = $UPLOAD_DIR . DIRECTORY_SEPARATOR . $mrn;
    if (!is_dir($mrnDir)) {
        @mkdir($mrnDir, 0775, true);
    }
    
    // Use transaction for batch processing
    db()->beginTransaction();
    
    try {
        foreach ($files['tmp_name'] as $idx => $tmp) {
            $name = $files['name'][$idx] ?? '';
            $size = (int)($files['size'][$idx] ?? 0);
            
            try {
                // Generate unique filename
                $dest = $mrnDir . DIRECTORY_SEPARATOR . bin2hex(random_bytes(16)) . '.dcm';
                
                // Move uploaded file
                if (!move_uploaded_file($tmp, $dest)) {
                    throw new Exception("Failed to save file to server");
                }
                
                // Validate DICOM signature
                if (!validate_dicom_signature($dest)) {
                    @unlink($dest);
                    throw new Exception("Not a valid DICOM file (missing DICM signature)");
                }
                
                // Insert into database
                $relPath = $mrn . '/' . basename($dest);
                $stmt = db()->prepare('INSERT INTO dicom_files (patient_id, file_path, uploaded_by, assigned_doctor, original_filename, file_size) VALUES (?,?,?,?,?,?)');
                $stmt->execute([$patientId, $relPath, $uploaderId, $doctorId, $name, $size]);
                
                $results['success_count']++;
                $results['successful_files'][] = $name;
                
            } catch (Exception $e) {
                $results['failed_count']++;
                $results['errors'][] = "File '$name': " . $e->getMessage();
                $results['failed_files'][] = $name;
            }
        }
        
        db()->commit();
        
    } catch (Exception $e) {
        db()->rollBack();
        $results['errors'][] = "Database error: " . $e->getMessage();
    }
    
    return $results;
}

function ensure_patient(string $mrn): int
{
    $stmt = db()->prepare('SELECT id FROM patients WHERE mrn = ?');
    $stmt->execute([$mrn]);
    $row = $stmt->fetch();
    if ($row) { return (int)$row['id']; }
    db()->prepare('INSERT INTO patients (mrn) VALUES (?)')->execute([$mrn]);
    return (int)db()->lastInsertId();
}

// Fetch own uploads with statistics
$stmt = db()->prepare("SELECT df.id, df.file_path, df.upload_date, df.original_filename, df.file_size, p.mrn, u.username AS doc_name
FROM dicom_files df 
JOIN patients p ON p.id = df.patient_id 
LEFT JOIN users u ON u.id = df.assigned_doctor
WHERE df.uploaded_by = ? 
ORDER BY df.upload_date DESC LIMIT 200");
$stmt->execute([$user['id']]);
$uploads = $stmt->fetchAll();

// Calculate statistics
$stats = [
    'total_uploads' => count($uploads),
    'total_size' => array_sum(array_column($uploads, 'file_size')),
    'unique_patients' => count(array_unique(array_column($uploads, 'mrn')))
];

include __DIR__ . '/partials/header.php';
?>

<div class="dashboard-header">
    <h1><i class="fas fa-cloud-upload-alt"></i> Enhanced Uploader Dashboard</h1>
    <p>Welcome back, <?= htmlspecialchars($user['username']) ?>! Upload and manage DICOM files for patients with enhanced features.</p>
</div>

<?php if ($message): ?>
    <div class="alert alert-ok">
        <i class="fas fa-check-circle"></i>
        <?= htmlspecialchars($message) ?>
    </div>
<?php endif; ?>

<?php if ($error): ?>
    <div class="alert alert-error">
        <i class="fas fa-exclamation-circle"></i>
        <?= htmlspecialchars($error) ?>
    </div>
<?php endif; ?>

<?php if (!empty($uploadResults)): ?>
    <div class="upload-results">
        <h3><i class="fas fa-info-circle"></i> Upload Results</h3>
        
        <?php if (!empty($uploadResults['successful_files'])): ?>
            <div class="success-files">
                <h4>✅ Successfully Uploaded (<?= count($uploadResults['successful_files']) ?> files):</h4>
                <ul>
                    <?php foreach ($uploadResults['successful_files'] as $filename): ?>
                        <li><?= htmlspecialchars($filename) ?></li>
                    <?php endforeach; ?>
                </ul>
            </div>
        <?php endif; ?>
        
        <?php if (!empty($uploadResults['failed_files'])): ?>
            <div class="failed-files">
                <h4>❌ Failed Uploads (<?= count($uploadResults['failed_files']) ?> files):</h4>
                <ul>
                    <?php foreach ($uploadResults['failed_files'] as $filename): ?>
                        <li><?= htmlspecialchars($filename) ?></li>
                    <?php endforeach; ?>
                </ul>
            </div>
        <?php endif; ?>
    </div>
<?php endif; ?>

<!-- Statistics Cards -->
<div class="dashboard-stats">
    <div class="stat-card">
        <div class="stat-number"><?= number_format($stats['total_uploads']) ?></div>
        <div class="stat-label">Total Uploads</div>
    </div>
    <div class="stat-card">
        <div class="stat-number"><?= formatBytes($stats['total_size']) ?></div>
        <div class="stat-label">Total Size</div>
    </div>
    <div class="stat-card">
        <div class="stat-number"><?= number_format($stats['unique_patients']) ?></div>
        <div class="stat-label">Patients</div>
    </div>
</div>

<!-- Enhanced Upload Section -->
<div class="card">
    <div class="card-header">
        <h2><i class="fas fa-upload"></i> Enhanced DICOM File Upload</h2>
    </div>
    <div class="card-body">
        <form method="post" enctype="multipart/form-data" id="enhancedUploadForm">
            <?= csrf_field() ?>
            <input type="hidden" name="action" value="upload">
            
            <div class="form-grid">
                <div class="form-row">
                    <label for="mrn">Patient MRN *</label>
                    <input type="text" id="mrn" name="mrn" required placeholder="Enter patient MRN">
                    <small>Medical Record Number (e.g., 123456789)</small>
                </div>
                
                <div class="form-row">
                    <label for="doctor_id">Assign to Doctor *</label>
                    <select id="doctor_id" name="doctor_id" required>
                        <option value="">Select a doctor</option>
                        <?php foreach ($doctors as $d): ?>
                            <option value="<?= (int)$d['id'] ?>"><?= htmlspecialchars($d['username']) ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
            </div>
            
            <div class="form-row">
                <label for="files">DICOM Files *</label>
                <div class="enhanced-upload-area" id="enhancedUploadArea">
                    <div class="upload-zone" id="uploadZone">
                        <i class="fas fa-cloud-upload-alt upload-icon"></i>
                        <h3>Drag & Drop DICOM files here</h3>
                        <p><strong>Click here to browse files</strong></p>
                        <p class="upload-hint">Supports multiple files up to 50 files, 2GB each</p>
                    </div>
                    <input type="file" id="files" name="files[]" accept=".dcm" multiple required style="display: none;">
                    
                    <!-- File Preview Section -->
                    <div id="filePreview" class="file-preview" style="display: none;">
                        <div class="file-summary">
                            <h4><i class="fas fa-file-medical"></i> Selected Files</h4>
                            <div id="fileSummary"></div>
                        </div>
                        <div id="fileList" class="file-list"></div>
                        <div class="file-actions">
                            <button type="button" class="btn btn-secondary" onclick="clearFiles()">
                                <i class="fas fa-trash"></i> Clear All
                            </button>
                            <button type="button" class="btn btn-secondary" onclick="browseFiles()">
                                <i class="fas fa-folder-open"></i> Add More Files
                            </button>
                        </div>
                    </div>
                </div>
                
                <!-- Upload Progress -->
                <div id="uploadProgress" class="upload-progress" style="display: none;">
                    <div class="progress-bar">
                        <div class="progress-fill" id="progressFill"></div>
                    </div>
                    <div class="progress-text" id="progressText">Preparing upload...</div>
                </div>
                
                <small>Maximum file size: <?= formatBytes($MAX_UPLOAD_BYTES) ?> per file | Maximum 50 files per upload | Total upload limit: 10GB</small>
            </div>
            
            <div class="form-row">
                <button type="submit" class="btn btn-primary btn-lg" id="uploadBtn">
                    <i class="fas fa-upload"></i> Upload Files
                </button>
                <button type="button" class="btn btn-secondary" onclick="window.location.href='dashboard_uploader.php'">
                    <i class="fas fa-arrow-left"></i> Back to Original Upload
                </button>
            </div>
        </form>
    </div>
</div>

<!-- Recent Uploads Section -->
<div class="card">
    <div class="card-header">
        <h2><i class="fas fa-history"></i> Recent Uploads</h2>
    </div>
    <div class="card-body">
        <div class="table-container">
            <table class="table">
                <thead>
                    <tr>
                        <th>File</th>
                        <th>Patient MRN</th>
                        <th>Assigned Doctor</th>
                        <th>Size</th>
                        <th>Upload Date</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($uploads as $upload): ?>
                        <tr>
                            <td>
                                <i class="fas fa-file-medical"></i>
                                <?= htmlspecialchars($upload['original_filename']) ?>
                            </td>
                            <td><?= htmlspecialchars($upload['mrn']) ?></td>
                            <td><?= htmlspecialchars($upload['doc_name'] ?? 'Unassigned') ?></td>
                            <td><?= formatBytes($upload['file_size']) ?></td>
                            <td><?= date('M j, Y g:i A', strtotime($upload['upload_date'])) ?></td>
                            <td>
                                <a href="<?= app_url('view_dicom.php?id=' . $upload['id']) ?>" class="btn btn-sm btn-primary">
                                    <i class="fas fa-eye"></i> View
                                </a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<style>
.enhanced-upload-area {
    border: 2px dashed #ddd;
    border-radius: 8px;
    padding: 20px;
    text-align: center;
    transition: all 0.3s ease;
    background: #fafafa;
}

.enhanced-upload-area.dragover {
    border-color: #007cba;
    background: #f0f9ff;
    transform: scale(1.02);
}

.upload-zone {
    cursor: pointer;
}

.upload-icon {
    font-size: 3rem;
    color: #666;
    margin-bottom: 1rem;
}

.upload-hint {
    font-size: 0.875rem;
    color: #666;
    margin-top: 0.5rem;
}

.file-preview {
    margin-top: 1rem;
    text-align: left;
}

.file-summary {
    background: #e8f5e8;
    padding: 1rem;
    border-radius: 6px;
    margin-bottom: 1rem;
}

.file-summary h4 {
    margin: 0 0 0.5rem 0;
    color: #2d5a2d;
}

.file-list {
    max-height: 200px;
    overflow-y: auto;
    border: 1px solid #ddd;
    border-radius: 4px;
    padding: 0.5rem;
}

.file-list ul {
    list-style: none;
    padding: 0;
    margin: 0;
}

.file-list li {
    padding: 0.5rem;
    margin: 0.25rem 0;
    background: #f8fafc;
    border-radius: 4px;
    font-size: 0.875rem;
    display: flex;
    align-items: center;
    gap: 0.5rem;
}

.file-list li i {
    color: #007cba;
}

.file-actions {
    margin-top: 1rem;
    display: flex;
    gap: 0.5rem;
}

.upload-progress {
    margin-top: 1rem;
    padding: 1rem;
    background: #f8fafc;
    border-radius: 6px;
}

.progress-bar {
    width: 100%;
    height: 20px;
    background: #e2e8f0;
    border-radius: 10px;
    overflow: hidden;
    margin-bottom: 0.5rem;
}

.progress-fill {
    height: 100%;
    background: linear-gradient(90deg, #007cba, #005a87);
    width: 0%;
    transition: width 0.3s ease;
}

.progress-text {
    text-align: center;
    font-size: 0.875rem;
    color: #666;
}

.upload-results {
    background: #f8fafc;
    border: 1px solid #ddd;
    border-radius: 6px;
    padding: 1rem;
    margin-bottom: 1rem;
}

.upload-results h3 {
    margin: 0 0 1rem 0;
    color: #333;
}

.success-files, .failed-files {
    margin-bottom: 1rem;
}

.success-files h4 {
    color: #2d5a2d;
    margin: 0 0 0.5rem 0;
}

.failed-files h4 {
    color: #d32f2f;
    margin: 0 0 0.5rem 0;
}

.upload-results ul {
    margin: 0;
    padding-left: 1.5rem;
}

.upload-results li {
    margin: 0.25rem 0;
    font-size: 0.875rem;
}
</style>

<script src="<?= app_url('js/enhanced_upload.js') ?>"></script>

<?php include __DIR__ . '/partials/footer.php'; ?>
