// Enhanced Upload functionality for DICOM files
document.addEventListener('DOMContentLoaded', function() {
    const uploadArea = document.getElementById('enhancedUploadArea');
    const uploadZone = document.getElementById('uploadZone');
    const fileInput = document.getElementById('files');
    const filePreview = document.getElementById('filePreview');
    const fileList = document.getElementById('fileList');
    const fileSummary = document.getElementById('fileSummary');
    const uploadProgress = document.getElementById('uploadProgress');
    const progressFill = document.getElementById('progressFill');
    const progressText = document.getElementById('progressText');
    const uploadBtn = document.getElementById('uploadBtn');
    const uploadForm = document.getElementById('enhancedUploadForm');

    if (!uploadArea || !fileInput || !fileList) {
        console.error('Enhanced upload elements not found');
        return;
    }

    // Click to browse files
    uploadZone.addEventListener('click', function(e) {
        // Don't trigger if clicking on the file input itself
        if (e.target !== fileInput) {
            fileInput.click();
        }
    });

    // Drag and drop events
    uploadArea.addEventListener('dragover', function(e) {
        e.preventDefault();
        uploadArea.classList.add('dragover');
        uploadZone.innerHTML = `
            <i class="fas fa-cloud-download-alt upload-icon"></i>
            <h3>Drop files here</h3>
            <p><strong>Release to upload</strong></p>
        `;
    });

    uploadArea.addEventListener('dragleave', function(e) {
        e.preventDefault();
        uploadArea.classList.remove('dragover');
        uploadZone.innerHTML = `
            <i class="fas fa-cloud-upload-alt upload-icon"></i>
            <h3>Drag & Drop DICOM files here</h3>
            <p><strong>Click here to browse files</strong></p>
            <p class="upload-hint">Supports multiple files up to 50 files, 2GB each</p>
        `;
    });

    uploadArea.addEventListener('drop', function(e) {
        e.preventDefault();
        uploadArea.classList.remove('dragover');
        uploadZone.innerHTML = `
            <i class="fas fa-cloud-upload-alt upload-icon"></i>
            <h3>Drag & Drop DICOM files here</h3>
            <p><strong>Click here to browse files</strong></p>
            <p class="upload-hint">Supports multiple files up to 50 files, 2GB each</p>
        `;
        
        if (e.dataTransfer.files) {
            fileInput.files = e.dataTransfer.files;
            updateFileList();
        }
    });

    // File input change event
    fileInput.addEventListener('change', updateFileList);

    // Form submission with progress tracking
    uploadForm.addEventListener('submit', function(e) {
        const files = fileInput.files;
        if (files.length === 0) {
            e.preventDefault();
            alert('Please select at least one DICOM file to upload.');
            return;
        }

        // Validate files before upload
        const validationErrors = validateFiles(files);
        if (validationErrors.length > 0) {
            e.preventDefault();
            alert('Upload validation failed:\n' + validationErrors.join('\n'));
            return;
        }

        // Show progress bar
        showUploadProgress();
        
        // Disable upload button
        uploadBtn.disabled = true;
        uploadBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Uploading...';
    });

    function updateFileList() {
        const files = fileInput.files;
        
        if (files && files.length > 0) {
            // Show file preview section
            filePreview.style.display = 'block';
            
            // Update file summary
            updateFileSummary(files);
            
            // Update file list
            const list = document.createElement('ul');
            list.style.listStyle = 'none';
            list.style.padding = '0';
            list.style.margin = '0';
            
            for (let file of files) {
                const li = document.createElement('li');
                li.style.padding = '0.5rem';
                li.style.margin = '0.25rem 0';
                li.style.background = '#f8fafc';
                li.style.borderRadius = '4px';
                li.style.fontSize = '0.875rem';
                li.style.display = 'flex';
                li.style.alignItems = 'center';
                li.style.gap = '0.5rem';
                
                // Get file icon based on type
                const fileIcon = getFileIcon(file.name);
                
                li.innerHTML = `
                    <i class="${fileIcon}" style="color: #007cba;"></i>
                    <span style="flex: 1;">${file.name}</span>
                    <span style="color: #666; font-size: 0.75rem;">${formatBytes(file.size)}</span>
                    <button type="button" class="btn btn-sm btn-danger" onclick="removeFile('${file.name}')" style="margin-left: 0.5rem;">
                        <i class="fas fa-times"></i>
                    </button>
                `;
                list.appendChild(li);
            }
            
            fileList.innerHTML = '';
            fileList.appendChild(list);
        } else {
            filePreview.style.display = 'none';
        }
    }

    function updateFileSummary(files) {
        let totalSize = 0;
        let fileCount = files.length;
        
        for (let file of files) {
            totalSize += file.size;
        }
        
        fileSummary.innerHTML = `
            <div style="display: flex; justify-content: space-between; align-items: center;">
                <div>
                    <strong>${fileCount} file(s) selected</strong><br>
                    <span style="color: #666; font-size: 0.875rem;">Total size: ${formatBytes(totalSize)}</span>
                </div>
                <div style="text-align: right;">
                    <span style="color: #2d5a2d; font-weight: bold;">✓ Ready to upload</span>
                </div>
            </div>
        `;
    }

    function validateFiles(files) {
        const errors = [];
        const maxSize = 2 * 1024 * 1024 * 1024; // 2GB
        const maxFiles = 50;
        let totalSize = 0;
        
        if (files.length > maxFiles) {
            errors.push(`Maximum ${maxFiles} files allowed per upload`);
        }
        
        for (let file of files) {
            // Check file extension
            if (!file.name.toLowerCase().endsWith('.dcm')) {
                errors.push(`${file.name}: Not a DICOM file (.dcm extension required)`);
            }
            
            // Check file size
            if (file.size <= 0) {
                errors.push(`${file.name}: Invalid file size (0 bytes)`);
            } else if (file.size > maxSize) {
                errors.push(`${file.name}: File too large (${formatBytes(file.size)} > ${formatBytes(maxSize)})`);
            }
            
            totalSize += file.size;
        }
        
        // Check total size (10GB limit)
        const maxTotalSize = 10 * 1024 * 1024 * 1024;
        if (totalSize > maxTotalSize) {
            errors.push(`Total upload size too large (${formatBytes(totalSize)} > ${formatBytes(maxTotalSize)})`);
        }
        
        return errors;
    }

    function getFileIcon(filename) {
        if (filename.toLowerCase().endsWith('.dcm')) {
            return 'fas fa-file-medical';
        }
        return 'fas fa-file';
    }

    function showUploadProgress() {
        uploadProgress.style.display = 'block';
        
        // Simulate progress (since we can't track actual upload progress with regular form submission)
        let progress = 0;
        const interval = setInterval(() => {
            progress += Math.random() * 15;
            if (progress > 90) {
                progress = 90; // Don't go to 100% until actually complete
            }
            
            progressFill.style.width = progress + '%';
            progressText.textContent = `Uploading... ${Math.round(progress)}%`;
        }, 200);
        
        // Store interval for cleanup
        uploadForm.dataset.progressInterval = interval;
    }

    function hideUploadProgress() {
        uploadProgress.style.display = 'none';
        progressFill.style.width = '0%';
        progressText.textContent = 'Preparing upload...';
        
        // Clear interval if exists
        if (uploadForm.dataset.progressInterval) {
            clearInterval(parseInt(uploadForm.dataset.progressInterval));
            delete uploadForm.dataset.progressInterval;
        }
    }

    function formatBytes(bytes, decimals = 2) {
        if (bytes === 0) return '0 Bytes';
        const k = 1024;
        const dm = decimals < 0 ? 0 : decimals;
        const sizes = ['Bytes', 'KB', 'MB', 'GB', 'TB'];
        const i = Math.floor(Math.log(bytes) / Math.log(k));
        return parseFloat((bytes / Math.pow(k, i)).toFixed(dm)) + ' ' + sizes[i];
    }

    // Global functions for buttons
    window.clearFiles = function() {
        fileInput.value = '';
        updateFileList();
        hideUploadProgress();
        
        // Re-enable upload button
        uploadBtn.disabled = false;
        uploadBtn.innerHTML = '<i class="fas fa-upload"></i> Upload Files';
    };

    window.browseFiles = function() {
        fileInput.click();
    };

    window.removeFile = function(filename) {
        // Create a new FileList without the specified file
        const files = fileInput.files;
        const dt = new DataTransfer();
        
        for (let i = 0; i < files.length; i++) {
            if (files[i].name !== filename) {
                dt.items.add(files[i]);
            }
        }
        
        fileInput.files = dt.files;
        updateFileList();
    };

    // Debug info
    console.log('Enhanced upload functionality initialized');
    console.log('Upload area:', uploadArea);
    console.log('File input:', fileInput);
    console.log('File list:', fileList);
});
