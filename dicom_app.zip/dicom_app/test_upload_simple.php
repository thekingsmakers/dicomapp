<!DOCTYPE html>
<html>
<head>
    <title>Simple Upload Test - No CSP</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 20px; }
        .upload-area { 
            border: 2px dashed #ccc; 
            padding: 20px; 
            text-align: center; 
            margin: 20px 0;
            cursor: pointer;
        }
        .upload-area:hover { border-color: #007cba; background: #f0f9ff; }
        .file-list { margin-top: 10px; text-align: left; }
        .file-item { padding: 5px; margin: 2px 0; background: #f8f9fa; border-radius: 4px; }
    </style>
</head>
<body>
    <h1>Simple Upload Test (No CSP Restrictions)</h1>
    
    <form method="post" enctype="multipart/form-data">
        <div class="upload-area" onclick="document.getElementById('files').click();">
            <h3>Click here to browse files</h3>
            <p>or drag and drop files here</p>
            <input type="file" id="files" name="files[]" multiple accept=".dcm" style="display: none;">
        </div>
        
        <div id="fileList" class="file-list"></div>
        
        <button type="submit">Upload Files</button>
    </form>

    <script>
        const uploadArea = document.querySelector('.upload-area');
        const fileInput = document.getElementById('files');
        const fileList = document.getElementById('fileList');

        // Click to browse
        uploadArea.addEventListener('click', function(e) {
            if (e.target !== fileInput) {
                fileInput.click();
            }
        });

        // Drag and drop
        uploadArea.addEventListener('dragover', function(e) {
            e.preventDefault();
            uploadArea.style.borderColor = '#007cba';
            uploadArea.style.background = '#f0f9ff';
        });

        uploadArea.addEventListener('dragleave', function(e) {
            e.preventDefault();
            uploadArea.style.borderColor = '#ccc';
            uploadArea.style.background = 'white';
        });

        uploadArea.addEventListener('drop', function(e) {
            e.preventDefault();
            uploadArea.style.borderColor = '#ccc';
            uploadArea.style.background = 'white';
            
            fileInput.files = e.dataTransfer.files;
            updateFileList();
        });

        // File input change
        fileInput.addEventListener('change', updateFileList);

        function updateFileList() {
            fileList.innerHTML = '';
            const files = fileInput.files;
            
            if (files.length > 0) {
                for (let file of files) {
                    const div = document.createElement('div');
                    div.className = 'file-item';
                    div.innerHTML = `<strong>${file.name}</strong> (${formatBytes(file.size)})`;
                    fileList.appendChild(div);
                }
            }
        }

        function formatBytes(bytes) {
            if (bytes === 0) return '0 Bytes';
            const k = 1024;
            const sizes = ['Bytes', 'KB', 'MB', 'GB'];
            const i = Math.floor(Math.log(bytes) / Math.log(k));
            return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
        }
    </script>

    <?php
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_FILES['files'])) {
        echo "<h2>Upload Results:</h2>";
        
        foreach ($_FILES['files']['tmp_name'] as $key => $tmp_name) {
            $name = $_FILES['files']['name'][$key];
            $size = $_FILES['files']['size'][$key];
            $error = $_FILES['files']['error'][$key];
            
            echo "<p><strong>$name</strong> ($size bytes) - ";
            
            if ($error === UPLOAD_ERR_OK) {
                echo "<span style='color: green;'>✅ Upload successful</span>";
            } else {
                $errorMessages = [
                    UPLOAD_ERR_INI_SIZE => 'File too large',
                    UPLOAD_ERR_FORM_SIZE => 'File exceeds form limit',
                    UPLOAD_ERR_PARTIAL => 'Partial upload',
                    UPLOAD_ERR_NO_FILE => 'No file',
                    UPLOAD_ERR_NO_TMP_DIR => 'No temp directory',
                    UPLOAD_ERR_CANT_WRITE => 'Cannot write',
                    UPLOAD_ERR_EXTENSION => 'Extension error'
                ];
                echo "<span style='color: red;'>❌ " . ($errorMessages[$error] ?? 'Unknown error') . "</span>";
            }
            echo "</p>";
        }
    }
    ?>
</body>
</html>
