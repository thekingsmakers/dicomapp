<?php
declare(strict_types=1);

require_once __DIR__ . '/config.php';
require_once __DIR__ . '/lib/auth.php';
require_once __DIR__ . '/lib/db.php';

// Ensure user is logged in
ensure_session_started();
if (!current_user()) {
    http_response_code(401);
    exit('Unauthorized');
}

// Get file ID from request
$fileId = (int)($_GET['id'] ?? 0);
if ($fileId <= 0) {
    http_response_code(400);
    exit('Invalid file ID');
}

// Fetch file information from database
$stmt = db()->prepare("SELECT df.file_path, df.original_filename, p.mrn 
                       FROM dicom_files df 
                       JOIN patients p ON p.id = df.patient_id 
                       WHERE df.id = ?");
$stmt->execute([$fileId]);
$file = $stmt->fetch();

if (!$file) {
    http_response_code(404);
    exit('File not found');
}

// Check if user has access to this file
$user = current_user();
if ($user['role'] !== 'admin') {
    // For non-admin users, check if they have access to this file
    if ($user['role'] === 'doctor') {
        $stmt = db()->prepare("SELECT 1 FROM dicom_files WHERE id = ? AND assigned_doctor = ?");
        $stmt->execute([$fileId, $user['id']]);
        if (!$stmt->fetch()) {
            http_response_code(403);
            exit('Access denied');
        }
    } elseif ($user['role'] === 'uploader') {
        $stmt = db()->prepare("SELECT 1 FROM dicom_files WHERE id = ? AND uploaded_by = ?");
        $stmt->execute([$fileId, $user['id']]);
        if (!$stmt->fetch()) {
            http_response_code(403);
            exit('Access denied');
        }
    }
}

// Build file path
$filePath = $UPLOAD_DIR . DIRECTORY_SEPARATOR . $file['file_path'];

if (!file_exists($filePath)) {
    http_response_code(404);
    exit('File not found on disk');
}

// Set CORS headers for Cornerstone.js
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Range');

// Set DICOM-specific headers
header('Content-Type: application/octet-stream');
header('Content-Disposition: inline; filename="' . basename($file['original_filename']) . '"');
header('Content-Length: ' . filesize($filePath));
header('Accept-Ranges: bytes');

// Output the file
readfile($filePath);


