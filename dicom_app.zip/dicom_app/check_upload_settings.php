<?php
// Check if .htaccess upload settings are being applied
echo "<h1>Upload Settings Check</h1>";

echo "<h2>Current PHP Upload Settings:</h2>";
echo "<ul>";
echo "<li>file_uploads: " . (ini_get('file_uploads') ? 'ON' : 'OFF') . "</li>";
echo "<li>upload_max_filesize: " . ini_get('upload_max_filesize') . "</li>";
echo "<li>post_max_size: " . ini_get('post_max_size') . "</li>";
echo "<li>max_execution_time: " . ini_get('max_execution_time') . "</li>";
echo "<li>max_input_time: " . ini_get('max_input_time') . "</li>";
echo "<li>memory_limit: " . ini_get('memory_limit') . "</li>";
echo "</ul>";

echo "<h2>Expected Settings (from .htaccess):</h2>";
echo "<ul>";
echo "<li>upload_max_filesize: 2G</li>";
echo "<li>post_max_size: 2G</li>";
echo "<li>max_execution_time: 300</li>";
echo "<li>max_input_time: 300</li>";
echo "<li>memory_limit: 512M</li>";
echo "</ul>";

echo "<h2>Status:</h2>";
$uploadSize = ini_get('upload_max_filesize');
$postSize = ini_get('post_max_size');

if ($uploadSize === '2G' || $uploadSize === '2048M') {
    echo "<p style='color: green;'>✅ upload_max_filesize is correctly set to 2G</p>";
} else {
    echo "<p style='color: red;'>❌ upload_max_filesize is set to: $uploadSize (should be 2G)</p>";
}

if ($postSize === '2G' || $postSize === '2048M') {
    echo "<p style='color: green;'>✅ post_max_size is correctly set to 2G</p>";
} else {
    echo "<p style='color: red;'>❌ post_max_size is set to: $postSize (should be 2G)</p>";
}

echo "<h2>Recommendations:</h2>";
if ($uploadSize !== '2G' && $uploadSize !== '2048M') {
    echo "<p style='color: orange;'>⚠️ The .htaccess file settings are not being applied. You may need to:</p>";
    echo "<ul>";
    echo "<li>Restart Apache web server</li>";
    echo "<li>Check if mod_php is enabled</li>";
    echo "<li>Verify .htaccess file is in the correct location</li>";
    echo "<li>Check Apache error logs for any .htaccess related errors</li>";
    echo "</ul>";
}
?>
