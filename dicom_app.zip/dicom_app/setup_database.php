<?php
declare(strict_types=1);

require_once __DIR__ . '/config.php';

echo "<h2>DICOM App Database Setup</h2>";

try {
    // Connect to database
    $pdo = new PDO($DB_DSN, $DB_USER, $DB_PASS, [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    ]);
    
    echo "✅ Database connection successful<br><br>";
    
    // Check if users table exists
    $stmt = $pdo->query("SHOW TABLES LIKE 'users'");
    if ($stmt->rowCount() === 0) {
        echo "❌ Users table does not exist. Creating database schema...<br>";
        
        // Read and execute the SQL file
        $sql = file_get_contents('db.sql');
        $pdo->exec($sql);
        echo "✅ Database schema created<br><br>";
    } else {
        echo "✅ Users table exists<br><br>";
    }
    
    // Define users to create/update
    $users = [
        [
            'username' => 'admin',
            'password' => 'Admin@123',
            'role' => 'admin'
        ],
        [
            'username' => 'doctor1',
            'password' => 'Admin@123',
            'role' => 'doctor'
        ],
        [
            'username' => 'uploader1',
            'password' => 'Admin@123',
            'role' => 'uploader'
        ]
    ];
    
    echo "<h3>Setting up users:</h3>";
    
    foreach ($users as $userData) {
        $username = $userData['username'];
        $password = $userData['password'];
        $role = $userData['role'];
        
        // Check if user exists
        $stmt = $pdo->prepare("SELECT id FROM users WHERE username = ?");
        $stmt->execute([$username]);
        $existingUser = $stmt->fetch();
        
        if ($existingUser) {
            // Update existing user's password
            $passwordHash = password_hash($password, PASSWORD_DEFAULT);
            $stmt = $pdo->prepare("UPDATE users SET password_hash = ?, role = ? WHERE username = ?");
            $stmt->execute([$passwordHash, $role, $username]);
            echo "✅ Updated user: {$username} (Role: {$role})<br>";
        } else {
            // Create new user
            $passwordHash = password_hash($password, PASSWORD_DEFAULT);
            $stmt = $pdo->prepare("INSERT INTO users (username, password_hash, role) VALUES (?, ?, ?)");
            $stmt->execute([$username, $passwordHash, $role]);
            echo "✅ Created user: {$username} (Role: {$role})<br>";
        }
    }
    
    echo "<br><h3>Current users in database:</h3>";
    $stmt = $pdo->query("SELECT id, username, role FROM users ORDER BY username");
    $allUsers = $stmt->fetchAll();
    
    if (count($allUsers) > 0) {
        echo "<table border='1' style='border-collapse: collapse; width: 100%;'>";
        echo "<tr><th>ID</th><th>Username</th><th>Role</th></tr>";
        foreach ($allUsers as $user) {
            echo "<tr>";
            echo "<td>{$user['id']}</td>";
            echo "<td>{$user['username']}</td>";
            echo "<td>{$user['role']}</td>";
            echo "</tr>";
        }
        echo "</table>";
    } else {
        echo "❌ No users found in database<br>";
    }
    
    echo "<br><h3>Login Instructions:</h3>";
    echo "You can now log in with any of these credentials:<br>";
    echo "- Username: admin, Password: Admin@123 (Admin role)<br>";
    echo "- Username: doctor1, Password: Admin@123 (Doctor role)<br>";
    echo "- Username: uploader1, Password: Admin@123 (Uploader role)<br>";
    echo "<br><a href='login.php'>Go to Login Page</a>";
    
} catch (PDOException $e) {
    echo "❌ Database error: " . $e->getMessage() . "<br>";
    echo "<br>Please check your database configuration in config.php<br>";
}
?>
