<?php
// Simple upload test script
echo "<h1>Upload Test</h1>";

// Check PHP upload settings
echo "<h2>PHP Upload Settings:</h2>";
echo "<ul>";
echo "<li>file_uploads: " . (ini_get('file_uploads') ? 'ON' : 'OFF') . "</li>";
echo "<li>upload_max_filesize: " . ini_get('upload_max_filesize') . "</li>";
echo "<li>post_max_size: " . ini_get('post_max_size') . "</li>";
echo "<li>max_execution_time: " . ini_get('max_execution_time') . "</li>";
echo "<li>max_input_time: " . ini_get('max_input_time') . "</li>";
echo "<li>memory_limit: " . ini_get('memory_limit') . "</li>";
echo "</ul>";

// Check if uploads directory exists and is writable
$uploadDir = __DIR__ . '/uploads';
echo "<h2>Upload Directory:</h2>";
echo "<ul>";
echo "<li>Directory exists: " . (is_dir($uploadDir) ? 'YES' : 'NO') . "</li>";
echo "<li>Directory writable: " . (is_writable($uploadDir) ? 'YES' : 'NO') . "</li>";
echo "<li>Directory path: " . $uploadDir . "</li>";
echo "</ul>";

// Simple upload form
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_FILES['testfile'])) {
    echo "<h2>Upload Result:</h2>";
    
    $file = $_FILES['testfile'];
    echo "<ul>";
    echo "<li>File name: " . htmlspecialchars($file['name']) . "</li>";
    echo "<li>File size: " . $file['size'] . " bytes</li>";
    echo "<li>File type: " . htmlspecialchars($file['type']) . "</li>";
    echo "<li>Upload error: " . $file['error'] . "</li>";
    echo "<li>Temporary file: " . htmlspecialchars($file['tmp_name']) . "</li>";
    echo "</ul>";
    
    if ($file['error'] === UPLOAD_ERR_OK) {
        $dest = $uploadDir . '/' . basename($file['name']);
        if (move_uploaded_file($file['tmp_name'], $dest)) {
            echo "<p style='color: green;'>✅ File uploaded successfully to: " . htmlspecialchars($dest) . "</p>";
        } else {
            echo "<p style='color: red;'>❌ Failed to move uploaded file</p>";
        }
    } else {
        $errorMessages = [
            UPLOAD_ERR_INI_SIZE => 'File exceeds PHP upload_max_filesize',
            UPLOAD_ERR_FORM_SIZE => 'File exceeds MAX_FILE_SIZE',
            UPLOAD_ERR_PARTIAL => 'File was only partially uploaded',
            UPLOAD_ERR_NO_FILE => 'No file was uploaded',
            UPLOAD_ERR_NO_TMP_DIR => 'Missing temporary folder',
            UPLOAD_ERR_CANT_WRITE => 'Failed to write file to disk',
            UPLOAD_ERR_EXTENSION => 'A PHP extension stopped the file upload'
        ];
        echo "<p style='color: red;'>❌ Upload error: " . ($errorMessages[$file['error']] ?? 'Unknown error') . "</p>";
    }
}

echo "<h2>Test Upload Form:</h2>";
echo "<form method='post' enctype='multipart/form-data'>";
echo "<input type='file' name='testfile' required>";
echo "<button type='submit'>Upload Test File</button>";
echo "</form>";
?>
