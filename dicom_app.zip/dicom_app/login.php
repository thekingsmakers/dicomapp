<?php
declare(strict_types=1);

require_once __DIR__ . '/config.php';
require_once __DIR__ . '/lib/auth.php';
require_once __DIR__ . '/lib/csrf.php';

// Start session for CSRF
if (session_status() !== PHP_SESSION_ACTIVE) {
    session_start();
}

// Redirect if already logged in
if (current_user()) {
    $user = current_user();
    $dashboard_url = 'dashboard_' . $user['role'] . '.php';
    header('Location: ' . $dashboard_url);
    exit;
}

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';
    
    // Debug information (using error_log instead of echo)
    error_log("Login attempt - Username: " . $username);
    error_log("CSRF token present: " . (isset($_POST['csrf_token']) ? 'yes' : 'no'));
    
    // Verify CSRF token
    try {
        verify_csrf_token();
        error_log("CSRF token verification passed");
    } catch (Exception $e) {
        error_log("CSRF token error: " . $e->getMessage());
        $error = 'Security token validation failed. Please try again.';
    }
    
    if (empty($error)) {
        if (empty($username) || empty($password)) {
            $error = 'Please enter both username and password.';
            error_log("Login failed - empty username or password");
        } else {
            try {
                error_log("Attempting login for user: " . $username);
                
                // Use the proper authentication system
                if (attempt_login($username, $password)) {
                    error_log("Login successful for user: " . $username);
                    $user = current_user();
                    if ($user && isset($user['role'])) {
                        $dashboard_url = 'dashboard_' . $user['role'] . '.php';
                        error_log("Redirecting to: " . $dashboard_url);
                        
                        // Redirect immediately without any output
                        header('Location: ' . $dashboard_url);
                        exit;
                    } else {
                        $error = 'Login successful but user role not found.';
                        error_log("Login successful but user role not found");
                    }
                } else {
                    $error = 'Invalid username or password.';
                    error_log("Login failed - invalid credentials for user: " . $username);
                }
            } catch (Exception $e) {
                $error = 'Authentication error: ' . $e->getMessage();
                error_log("Authentication exception: " . $e->getMessage());
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - DICOM Medical Imaging</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Inter', sans-serif;
            line-height: 1.6;
            background: #f8fafc;
        }

        .login-container {
            display: flex;
            min-height: 100vh;
            background: #f8fafc;
        }

        .login-background {
            flex: 1;
            background-image: url('img/logo.jpeg');
            background-size: cover;
            background-position: center;
            background-repeat: no-repeat;
            position: relative;
            overflow: hidden;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .background-overlay {
            text-align: center;
            color: white;
            z-index: 2;
            position: relative;
            padding: 2rem;
            background: rgba(0, 0, 0, 0.6);
            border-radius: 15px;
            backdrop-filter: blur(10px);
            box-shadow: 0 8px 32px rgba(0, 0, 0, 0.3);
        }

        .logo-section {
            margin-bottom: 3rem;
        }

        .app-title {
            font-size: 2.5rem;
            font-weight: 700;
            margin: 0 0 0.5rem 0;
            text-shadow: 0 2px 4px rgba(0,0,0,0.8);
        }

        .app-subtitle {
            font-size: 1.1rem;
            opacity: 0.95;
            margin: 0;
            font-weight: 300;
            text-shadow: 0 1px 2px rgba(0,0,0,0.8);
        }

        .background-features {
            display: flex;
            flex-direction: column;
            gap: 1.5rem;
            margin-top: 3rem;
        }

        .feature-item {
            display: flex;
            align-items: center;
            gap: 1rem;
            font-size: 1.1rem;
            opacity: 0.95;
            text-shadow: 0 1px 2px rgba(0,0,0,0.8);
        }

        .feature-item i {
            font-size: 1.5rem;
            width: 30px;
            text-align: center;
            color: #667eea;
        }

        .login-form-section {
            flex: 1;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 2rem;
            background: white;
            box-shadow: -5px 0 15px rgba(0, 0, 0, 0.1);
        }

        .login-form-container {
            width: 100%;
            max-width: 400px;
        }

        .form-header {
            text-align: center;
            margin-bottom: 2rem;
        }

        .form-header h2 {
            font-size: 2rem;
            font-weight: 700;
            color: #2d3748;
            margin: 0 0 0.5rem 0;
        }

        .form-header p {
            color: #718096;
            margin: 0;
            font-size: 1rem;
        }

        .alert {
            padding: 1rem;
            border-radius: 8px;
            margin-bottom: 1.5rem;
            display: flex;
            align-items: center;
            gap: 0.5rem;
            font-size: 0.875rem;
        }

        .alert-error {
            background-color: #fed7d7;
            color: #c53030;
            border: 1px solid #feb2b2;
        }

        .login-form {
            margin-bottom: 2rem;
        }

        .form-group {
            margin-bottom: 1.5rem;
        }

        .form-group label {
            display: flex;
            align-items: center;
            gap: 0.5rem;
            font-weight: 600;
            color: #4a5568;
            margin-bottom: 0.5rem;
            font-size: 0.875rem;
        }

        .form-group label i {
            color: #667eea;
        }

        .form-group input {
            width: 100%;
            padding: 0.75rem 1rem;
            border: 2px solid #e2e8f0;
            border-radius: 8px;
            font-size: 1rem;
            transition: all 0.2s ease;
            box-sizing: border-box;
        }

        .form-group input:focus {
            outline: none;
            border-color: #667eea;
            box-shadow: 0 0 0 3px rgba(102, 126, 234, 0.1);
        }

        .btn-login {
            width: 100%;
            padding: 0.875rem 1rem;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            border: none;
            border-radius: 8px;
            font-size: 1rem;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.2s ease;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 0.5rem;
        }

        .btn-login:hover {
            transform: translateY(-1px);
            box-shadow: 0 4px 12px rgba(102, 126, 234, 0.4);
        }

        .btn-login:active {
            transform: translateY(0);
        }

        .demo-credentials {
            background: #f7fafc;
            border: 1px solid #e2e8f0;
            border-radius: 8px;
            padding: 1.5rem;
            margin-bottom: 2rem;
        }

        .demo-credentials h4 {
            margin: 0 0 1rem 0;
            color: #2d3748;
            font-size: 1rem;
            text-align: center;
        }

        .credential-item {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 0.5rem 0;
            border-bottom: 1px solid #e2e8f0;
            font-size: 0.875rem;
        }

        .credential-item:last-child {
            border-bottom: none;
        }

        .credential-item strong {
            color: #4a5568;
        }

        .form-footer {
            text-align: center;
            color: #718096;
            font-size: 0.75rem;
        }

        /* Responsive Design */
        @media (max-width: 768px) {
            .login-container {
                flex-direction: column;
            }
            
            .login-background {
                min-height: 40vh;
                padding: 2rem 1rem;
            }
            
            .app-title {
                font-size: 2rem;
            }
            
            .background-features {
                flex-direction: row;
                flex-wrap: wrap;
                justify-content: center;
                gap: 1rem;
            }
            
            .feature-item {
                font-size: 0.9rem;
            }
            
            .login-form-section {
                padding: 1rem;
                box-shadow: none;
            }
        }

        @media (max-width: 480px) {
            .app-title {
                font-size: 1.75rem;
            }
            
            .app-subtitle {
                font-size: 1rem;
            }
            
            .background-features {
                flex-direction: column;
                gap: 1rem;
            }
        }
    </style>
</head>
<body>
    <div class="login-container">
        <!-- Left Side - Background with Logo Image -->
        <div class="login-background">
            <div class="background-overlay">
                <div class="logo-section">
                    <h1 class="app-title">DICOM Medical Imaging</h1>
                    <p class="app-subtitle">Professional Medical Image Management System</p>
                </div>
                <div class="background-features">
                    <div class="feature-item">
                        <i class="fas fa-x-ray"></i>
                        <span>Advanced DICOM Viewer</span>
                    </div>
                    <div class="feature-item">
                        <i class="fas fa-shield-alt"></i>
                        <span>Secure & HIPAA Compliant</span>
                    </div>
                    <div class="feature-item">
                        <i class="fas fa-users"></i>
                        <span>Multi-Role Access Control</span>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Right Side - Login Form -->
        <div class="login-form-section">
            <div class="login-form-container">
                <div class="form-header">
                    <h2>Welcome Back</h2>
                    <p>Sign in to access your medical imaging dashboard</p>
                </div>
                
                <?php if ($error): ?>
                    <div class="alert alert-error">
                        <i class="fas fa-exclamation-circle"></i>
                        <?= htmlspecialchars($error) ?>
                    </div>
                <?php endif; ?>
                
                <form method="POST" class="login-form">
                    <?= csrf_field() ?>
                    <div class="form-group">
                        <label for="username">
                            <i class="fas fa-user"></i>
                            Username
                        </label>
                        <input type="text" id="username" name="username" required 
                               placeholder="Enter your username"
                               value="<?= htmlspecialchars($_POST['username'] ?? '') ?>">
                    </div>
                    
                    <div class="form-group">
                        <label for="password">
                            <i class="fas fa-lock"></i>
                            Password
                        </label>
                        <input type="password" id="password" name="password" required 
                               placeholder="Enter your password">
                    </div>
                    
                    <button type="submit" class="btn-login">
                        <i class="fas fa-sign-in-alt"></i>
                        Sign In
                    </button>
                </form>
                
                <div class="demo-credentials">
                    <h4>Demo Credentials</h4>
                    <div class="credential-item">
                        <strong>Admin:</strong> admin
                    </div>
                    <div class="credential-item">
                        <strong>Doctor:</strong> doctor1
                    </div>
                    <div class="credential-item">
                        <strong>Uploader:</strong> uploader1
                    </div>
                    <div class="credential-item">
                        <strong>Password:</strong> Admin@123
                    </div>
                </div>
                
                <div class="form-footer">
                    <p>&copy; 2024 DICOM Medical Imaging System. All rights reserved.</p>
                </div>
            </div>
        </div>
    </div>
</body>
</html>

