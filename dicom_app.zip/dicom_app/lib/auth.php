<?php
declare(strict_types=1);

require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/db.php';

/**
 * Starts a secure session if not already started.
 */
function ensure_session_started(): void
{
    if (session_status() !== PHP_SESSION_ACTIVE) {
        session_start();
    }
}

/**
 * Attempt to authenticate a user.
 */
function attempt_login(string $username, string $password): bool
{
    $sql = 'SELECT id, username, password_hash, role FROM users WHERE username = ? LIMIT 1';
    $stmt = db()->prepare($sql);
    $stmt->execute([$username]);
    $user = $stmt->fetch();
    if (!$user || !password_verify($password, $user['password_hash'])) {
        return false;
    }
    ensure_session_started();
    
    // Set session data without regenerating ID (which can cause issues)
    $_SESSION['user'] = [
        'id' => (int)$user['id'],
        'username' => $user['username'],
        'role' => $user['role'],
    ];
    
    return true;
}

function logout(): void
{
    ensure_session_started();
    $_SESSION = [];
    if (ini_get('session.use_cookies')) {
        $params = session_get_cookie_params();
        setcookie(session_name(), '', time() - 42000, $params['path'], $params['domain'], $params['secure'], $params['httponly']);
    }
    session_destroy();
}

function current_user(): ?array
{
    ensure_session_started();
    return $_SESSION['user'] ?? null;
}

function require_login(): void
{
    ensure_session_started();
    if (empty($_SESSION['user'])) {
        header('Location: ' . app_url('login.php'));
        exit;
    }
}

function require_role(string $role): void
{
    require_login();
    $user = current_user();
    if (!$user || $user['role'] !== $role) {
        http_response_code(403);
        exit('Forbidden');
    }
}

function require_any_role(array $roles): void
{
    require_login();
    $user = current_user();
    if (!$user || !in_array($user['role'], $roles, true)) {
        http_response_code(403);
        exit('Forbidden');
    }
}


