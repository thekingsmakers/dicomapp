<?php
declare(strict_types=1);

// Include upload configuration override
require_once __DIR__ . '/php_upload_config.php';

require_once __DIR__ . '/config.php';
require_once __DIR__ . '/lib/auth.php';
require_once __DIR__ . '/lib/db.php';
require_once __DIR__ . '/lib/validation.php';
require_once __DIR__ . '/lib/csrf.php';

require_role('uploader');
global $UPLOAD_DIR, $MAX_UPLOAD_BYTES;

$user = current_user();
$message = '';
$error = '';

// Fetch doctors for dropdown
$doctors = db()->query("SELECT id, username FROM users WHERE role = 'doctor' ORDER BY username")->fetchAll();

if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'upload') {
    verify_csrf_token();
    $mrn = trim($_POST['mrn'] ?? '');
    $doctorId = (int)($_POST['doctor_id'] ?? 0);

    if (!validate_mrn($mrn)) {
        $error = 'Invalid MRN format';
    } elseif ($doctorId <= 0) {
        $error = 'Please select a doctor';
    } elseif (empty($_FILES['files']) || empty($_FILES['files']['name'][0])) {
        $error = 'No files uploaded. Please select at least one DICOM file.';
    } else {
        $patientId = ensure_patient($mrn);

        $mrnDir = $UPLOAD_DIR . DIRECTORY_SEPARATOR . $mrn;
        if (!is_dir($mrnDir)) {
            @mkdir($mrnDir, 0775, true);
        }

        $count = 0;
        $errors = [];
        foreach ((array)$_FILES['files']['tmp_name'] as $idx => $tmp) {
            $name = $_FILES['files']['name'][$idx] ?? '';
            $size = (int)($_FILES['files']['size'][$idx] ?? 0);
            $errorCode = (int)($_FILES['files']['error'][$idx] ?? UPLOAD_ERR_NO_FILE);
            
            if ($errorCode !== UPLOAD_ERR_OK) { 
                $errorMessages = [
                    UPLOAD_ERR_INI_SIZE => 'File exceeds PHP upload_max_filesize',
                    UPLOAD_ERR_FORM_SIZE => 'File exceeds MAX_FILE_SIZE',
                    UPLOAD_ERR_PARTIAL => 'File was only partially uploaded',
                    UPLOAD_ERR_NO_FILE => 'No file was uploaded',
                    UPLOAD_ERR_NO_TMP_DIR => 'Missing temporary folder',
                    UPLOAD_ERR_CANT_WRITE => 'Failed to write file to disk',
                    UPLOAD_ERR_EXTENSION => 'A PHP extension stopped the file upload'
                ];
                $errorMsg = $errorMessages[$errorCode] ?? 'Unknown upload error';
                $errors[] = "File '$name': $errorMsg";
                continue; 
            }
            if ($size <= 0) { 
                $errors[] = "File '$name' has invalid size (0 bytes)";
                continue; 
            }
            if ($size > $MAX_UPLOAD_BYTES) { 
                $errors[] = "File '$name' exceeds maximum size limit (" . formatBytes($MAX_UPLOAD_BYTES) . ")";
                continue; 
            }

            // Enforce .dcm extension
            if (!preg_match('/\.dcm$/i', $name)) { 
                $errors[] = "File '$name' is not a DICOM file (.dcm extension required)";
                continue; 
            }

            $dest = $mrnDir . DIRECTORY_SEPARATOR . bin2hex(random_bytes(16)) . '.dcm';
            if (!move_uploaded_file($tmp, $dest)) { 
                $errors[] = "Failed to save file '$name' to server";
                continue; 
            }
            if (!validate_dicom_signature($dest)) { 
                @unlink($dest);
                $errors[] = "File '$name' is not a valid DICOM file (missing DICM signature)";
                continue; 
            }

            $relPath = $mrn . '/' . basename($dest);
            $stmt = db()->prepare('INSERT INTO dicom_files (patient_id, file_path, uploaded_by, assigned_doctor, original_filename, file_size) VALUES (?,?,?,?,?,?)');
            $stmt->execute([$patientId, $relPath, $user['id'], $doctorId, $name, $size]);
            $count++;
        }
        
        if ($count > 0) {
            $message = $count . ' file(s) uploaded successfully';
            if (!empty($errors)) {
                $message .= ' (' . count($errors) . ' files failed)';
            }
        } else {
            $error = 'No files were uploaded successfully. ';
            if (!empty($errors)) {
                $error .= implode(', ', $errors);
            } else {
                $error .= 'Please check that your files are valid DICOM files (.dcm extension) and within the size limit.';
            }
        }
    }
}

function ensure_patient(string $mrn): int
{
    $stmt = db()->prepare('SELECT id FROM patients WHERE mrn = ?');
    $stmt->execute([$mrn]);
    $row = $stmt->fetch();
    if ($row) { return (int)$row['id']; }
    db()->prepare('INSERT INTO patients (mrn) VALUES (?)')->execute([$mrn]);
    return (int)db()->lastInsertId();
}

// Fetch own uploads with statistics
$stmt = db()->prepare("SELECT df.id, df.file_path, df.upload_date, df.original_filename, df.file_size, p.mrn, u.username AS doc_name
FROM dicom_files df 
JOIN patients p ON p.id = df.patient_id 
LEFT JOIN users u ON u.id = df.assigned_doctor
WHERE df.uploaded_by = ? 
ORDER BY df.upload_date DESC LIMIT 200");
$stmt->execute([$user['id']]);
$uploads = $stmt->fetchAll();

// Calculate statistics
$stats = [
    'total_uploads' => count($uploads),
    'total_size' => array_sum(array_column($uploads, 'file_size')),
    'unique_patients' => count(array_unique(array_column($uploads, 'mrn')))
];

include __DIR__ . '/partials/header.php';
?>

<div class="dashboard-header">
    <h1><i class="fas fa-cloud-upload-alt"></i> Uploader Dashboard</h1>
    <p>Welcome back, <?= htmlspecialchars($user['username']) ?>! Upload and manage DICOM files for patients.</p>
</div>

<?php if ($message): ?>
    <div class="alert alert-ok">
        <i class="fas fa-check-circle"></i>
        <?= htmlspecialchars($message) ?>
    </div>
<?php endif; ?>

<?php if ($error): ?>
    <div class="alert alert-error">
        <i class="fas fa-exclamation-circle"></i>
        <?= htmlspecialchars($error) ?>
    </div>
<?php endif; ?>

<!-- Statistics Cards -->
<div class="dashboard-stats">
    <div class="stat-card">
        <div class="stat-number"><?= number_format($stats['total_uploads']) ?></div>
        <div class="stat-label">Total Uploads</div>
    </div>
    <div class="stat-card">
        <div class="stat-number"><?= formatBytes($stats['total_size']) ?></div>
        <div class="stat-label">Total Size</div>
    </div>
    <div class="stat-card">
        <div class="stat-number"><?= number_format($stats['unique_patients']) ?></div>
        <div class="stat-label">Patients</div>
    </div>
</div>

<!-- Upload Section -->
<div class="card">
    <div class="card-header">
        <h2><i class="fas fa-upload"></i> Upload DICOM Files</h2>
    </div>
    <div class="card-body">
        <form method="post" enctype="multipart/form-data" id="uploadForm">
            <?= csrf_field() ?>
            <input type="hidden" name="action" value="upload">
            
            <div class="form-grid">
                <div class="form-row">
                    <label for="mrn">Patient MRN *</label>
                    <input type="text" id="mrn" name="mrn" required placeholder="Enter patient MRN">
                    <small>Medical Record Number (e.g., 123456789)</small>
                </div>
                
                <div class="form-row">
                    <label for="doctor_id">Assign to Doctor *</label>
                    <select id="doctor_id" name="doctor_id" required>
                        <option value="">Select a doctor</option>
                        <?php foreach ($doctors as $d): ?>
                            <option value="<?= (int)$d['id'] ?>"><?= htmlspecialchars($d['username']) ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
            </div>
            
            <div class="form-row">
                <label for="files">DICOM Files *</label>
                <div class="upload-area" id="uploadArea" style="cursor: pointer;">
                    <i class="fas fa-cloud-upload-alt" style="font-size: 3rem; color: var(--text-secondary); margin-bottom: 1rem;"></i>
                    <h3>Drag & Drop DICOM files here</h3>
                    <p><strong>Click here to browse files</strong></p>
                    <input type="file" id="files" name="files[]" accept=".dcm" multiple required style="display: none;">
                    <div id="fileList" style="margin-top: 1rem; text-align: left;"></div>
                </div>
                <div style="margin-top: 0.5rem;">
                    <button type="button" class="btn btn-secondary" onclick="browseFiles();">
                        <i class="fas fa-folder-open"></i> Browse Files
                    </button>
                </div>
                <small>Maximum file size: <?= formatBytes($MAX_UPLOAD_BYTES) ?> per file | Total upload limit: 2GB</small>
                <div style="margin-top: 0.5rem; padding: 0.5rem; background: #f8fafc; border-radius: 4px; font-size: 0.75rem; color: #666;">
                    <strong>Debug Info:</strong><br>
                    PHP upload_max_filesize: <?= ini_get('upload_max_filesize') ?><br>
                    PHP post_max_size: <?= ini_get('post_max_size') ?><br>
                    Upload directory writable: <?= is_writable($UPLOAD_DIR) ? 'Yes' : 'No' ?>
                </div>
            </div>
            
            <div class="form-row">
                <button type="submit" class="btn btn-primary btn-lg">
                    <i class="fas fa-upload"></i> Upload Files
                </button>
            </div>
        </form>
    </div>
</div>

<!-- Recent Uploads Section -->
<div class="card">
    <div class="card-header">
        <h2><i class="fas fa-history"></i> Recent Uploads</h2>
    </div>
    <div class="card-body">
        <div class="table-container">
            <table class="table">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Patient MRN</th>
                        <th>Filename</th>
                        <th>File Size</th>
                        <th>Upload Date</th>
                        <th>Assigned Doctor</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                <?php if (empty($uploads)): ?>
                    <tr>
                        <td colspan="7" class="empty-state">
                            <div class="empty-state-icon">📁</div>
                            <h3>No uploads yet</h3>
                            <p>Start by uploading your first DICOM file above.</p>
                        </td>
                    </tr>
                <?php else: ?>
                    <?php foreach ($uploads as $u): ?>
                        <tr>
                            <td><strong>#<?= (int)$u['id'] ?></strong></td>
                            <td>
                                <span class="badge badge-info"><?= htmlspecialchars($u['mrn']) ?></span>
                            </td>
                            <td><?= htmlspecialchars($u['original_filename'] ?? 'Unknown') ?></td>
                            <td><?= $u['file_size'] ? formatBytes($u['file_size']) : '—' ?></td>
                            <td><?= date('M j, Y g:i A', strtotime($u['upload_date'])) ?></td>
                            <td>
                                <?php if ($u['doc_name']): ?>
                                    <span class="badge badge-success"><?= htmlspecialchars($u['doc_name']) ?></span>
                                <?php else: ?>
                                    <span class="badge badge-warning">Unassigned</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <div class="actions">
                                    <a href="<?= htmlspecialchars(app_url('view_dicom.php?id=' . (int)$u['id'])) ?>" class="btn btn-sm btn-primary" title="View File">
                                        <i class="fas fa-eye"></i>
                                    </a>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>



<?php
function formatBytes($bytes, $precision = 2) {
    $units = array('B', 'KB', 'MB', 'GB', 'TB');
    for ($i = 0; $bytes > 1024 && $i < count($units) - 1; $i++) {
        $bytes /= 1024;
    }
    return round($bytes, $precision) . ' ' . $units[$i];
}
?>

<?php include __DIR__ . '/partials/footer.php'; ?>

