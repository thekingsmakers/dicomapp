<?php
declare(strict_types=1);

require_once __DIR__ . '/config.php';
require_once __DIR__ . '/lib/auth.php';
require_once __DIR__ . '/lib/db.php';

require_any_role(['admin', 'doctor', 'uploader']);

$user = current_user();
$fileId = (int)($_GET['id'] ?? 0);

if ($fileId <= 0) {
    header('Location: ' . app_url('dashboard_' . $user['role'] . '.php'));
    exit;
}

// Fetch file information
$stmt = db()->prepare("SELECT df.id, df.file_path, df.original_filename, df.file_size, df.upload_date, p.mrn, 
                              u.username AS doctor_name, up.username AS uploader_name, df.patient_id
                       FROM dicom_files df 
                       JOIN patients p ON p.id = df.patient_id 
                       LEFT JOIN users u ON u.id = df.assigned_doctor
                       LEFT JOIN users up ON up.id = df.uploaded_by
                       WHERE df.id = ?");
$stmt->execute([$fileId]);
$file = $stmt->fetch();

// Fetch all DICOM files for the same patient
$stmt = db()->prepare("SELECT df.id, df.original_filename, df.upload_date 
                       FROM dicom_files df 
                       WHERE df.patient_id = ? 
                       ORDER BY df.upload_date ASC");
$stmt->execute([$file['patient_id']]);
$patientFiles = $stmt->fetchAll();

// Find current file index
$currentIndex = 0;
foreach ($patientFiles as $index => $patientFile) {
    if ($patientFile['id'] == $fileId) {
        $currentIndex = $index;
        break;
    }
}

if (!$file) {
    header('Location: ' . app_url('dashboard_' . $user['role'] . '.php'));
    exit;
}

// Check access permissions
if ($user['role'] !== 'admin') {
    if ($user['role'] === 'doctor') {
        $stmt = db()->prepare("SELECT 1 FROM dicom_files WHERE id = ? AND assigned_doctor = ?");
        $stmt->execute([$fileId, $user['id']]);
        if (!$stmt->fetch()) {
            header('Location: ' . app_url('dashboard_' . $user['role'] . '.php'));
            exit;
        }
    } elseif ($user['role'] === 'uploader') {
        $stmt = db()->prepare("SELECT 1 FROM dicom_files WHERE id = ? AND uploaded_by = ?");
        $stmt->execute([$fileId, $user['id']]);
        if (!$stmt->fetch()) {
            header('Location: ' . app_url('dashboard_' . $user['role'] . '.php'));
            exit;
        }
    }
}

include __DIR__ . '/partials/header.php';
?>

<div class="dicom-viewer-container">
    <div class="viewer-header">
        <div class="viewer-info">
            <h1><i class="fas fa-x-ray"></i> DICOM Viewer</h1>
            <div class="file-details">
                <div class="detail-item">
                    <strong>Patient MRN:</strong> <?= htmlspecialchars($file['mrn']) ?>
                </div>
                <div class="detail-item">
                    <strong>Filename:</strong> <?= htmlspecialchars($file['original_filename']) ?>
                </div>
                <div class="detail-item">
                    <strong>File Size:</strong> <?= formatBytes($file['file_size']) ?>
                </div>
                <div class="detail-item">
                    <strong>Upload Date:</strong> <?= date('M j, Y g:i A', strtotime($file['upload_date'])) ?>
                </div>
                <?php if ($file['doctor_name']): ?>
                <div class="detail-item">
                    <strong>Assigned Doctor:</strong> <?= htmlspecialchars($file['doctor_name']) ?>
                </div>
                <?php endif; ?>
                <div class="detail-item">
                    <strong>Uploaded By:</strong> <?= htmlspecialchars($file['uploader_name']) ?>
                </div>
            </div>
        </div>
        <div class="viewer-actions">
            <?php if (count($patientFiles) > 1): ?>
            <div class="image-navigation">
                <button id="prevImage" class="btn btn-sm btn-outline" <?= $currentIndex === 0 ? 'disabled' : '' ?>>
                    <i class="fas fa-chevron-left"></i>
                </button>
                <span class="image-counter">
                    <?= ($currentIndex + 1) ?> of <?= count($patientFiles) ?>
                </span>
                <button id="nextImage" class="btn btn-sm btn-outline" <?= $currentIndex === (count($patientFiles) - 1) ? 'disabled' : '' ?>>
                    <i class="fas fa-chevron-right"></i>
                </button>
            </div>
            <?php endif; ?>
            <a href="<?= app_url('dashboard_' . $user['role'] . '.php') ?>" class="btn btn-secondary">
                <i class="fas fa-arrow-left"></i> Back to Dashboard
            </a>
        </div>
    </div>

    <div class="viewer-controls">
        <div class="control-group">
            <button id="windowLevel" class="btn btn-sm btn-primary">
                <i class="fas fa-adjust"></i> Window/Level
            </button>
            <button id="zoom" class="btn btn-sm btn-primary">
                <i class="fas fa-search"></i> Zoom
            </button>
            <button id="length" class="btn btn-sm btn-primary">
                <i class="fas fa-ruler"></i> Length
            </button>
            <button id="angle" class="btn btn-sm btn-primary">
                <i class="fas fa-compass"></i> Angle
            </button>
            <button id="reset" class="btn btn-sm btn-secondary">
                <i class="fas fa-undo"></i> Reset
            </button>
        </div>
        
        <!-- Video/Frame Controls -->
        <div class="control-group video-controls" id="videoControls" style="display: none;">
            <button id="playPause" class="btn btn-sm btn-success" disabled>
                <i class="fas fa-play"></i> Play (Coming Soon)
            </button>
            <button id="stop" class="btn btn-sm btn-warning" disabled>
                <i class="fas fa-stop"></i> Stop (Coming Soon)
            </button>
            <input type="range" id="frameSlider" min="0" max="100" value="0" style="width: 150px;" disabled>
            <span id="frameCounter">Frame 1</span>
            <input type="number" id="frameRate" min="1" max="30" value="10" style="width: 60px;" title="FPS" disabled>
            <label for="frameRate">FPS</label>
        </div>
        
        <!-- View Mode Controls -->
        <div class="control-group view-mode-controls">
            <button id="view2D" class="btn btn-sm btn-info active">
                <i class="fas fa-square"></i> 2D
            </button>
            <button id="view3D" class="btn btn-sm btn-info" disabled>
                <i class="fas fa-cube"></i> 3D (Coming Soon)
            </button>
            <button id="viewMulti" class="btn btn-sm btn-info" disabled>
                <i class="fas fa-th"></i> Multi-View (Coming Soon)
            </button>
        </div>
        
        <div class="control-group">
            <label for="windowLevelSlider">Window/Level:</label>
            <input type="range" id="windowLevelSlider" min="0" max="100" value="50">
            <span id="windowLevelValue">50</span>
        </div>
    </div>
    
    <!-- Tool Usage Instructions -->
    <div class="tool-instructions">
        <details>
            <summary><i class="fas fa-question-circle"></i> How to use the medical tools</summary>
            <div class="instructions-content">
                <div class="instruction-item">
                    <strong>Window/Level (W/L):</strong> Click the button, then drag left/right on the image to adjust brightness and contrast
                </div>
                <div class="instruction-item">
                    <strong>Zoom:</strong> Click the button, then scroll with mouse wheel or drag to zoom in/out
                </div>
                <div class="instruction-item">
                    <strong>Length:</strong> Click the button, then click and drag on the image to measure distances
                </div>
                <div class="instruction-item">
                    <strong>Angle:</strong> Click the button, then click three points to measure angles
                </div>
                <div class="instruction-item">
                    <strong>Reset:</strong> Click to reset the image view to default
                </div>
            </div>
        </details>
    </div>

    <div class="viewer-main">
        <!-- 2D Single View -->
        <div id="view2DContainer" class="view-container active">
            <div id="dicomImage" class="dicom-image-container"></div>
        </div>
        
        <!-- 3D View -->
        <div id="view3DContainer" class="view-container">
            <div id="dicom3D" class="dicom-3d-container">
                <div style="color: white; text-align: center; padding-top: 100px;">
                    <h3>3D View</h3>
                    <p>3D rendering is being implemented...</p>
                    <p><small>This will include volume rendering and 3D navigation</small></p>
                </div>
            </div>
        </div>
        
        <!-- Multi-View (2D) -->
        <div id="viewMultiContainer" class="view-container">
            <div class="multi-view-grid">
                <div class="view-cell" id="axialView">
                    <h4>Axial</h4>
                    <div class="dicom-image-container"></div>
                </div>
                <div class="view-cell" id="sagittalView">
                    <h4>Sagittal</h4>
                    <div class="dicom-image-container"></div>
                </div>
                <div class="view-cell" id="coronalView">
                    <h4>Coronal</h4>
                    <div class="dicom-image-container"></div>
                </div>
            </div>
        </div>
        
        <div class="viewer-sidebar">
            <div class="dicom-info">
                <h3>DICOM Information</h3>
                <div id="dicomMetadata">
                    <p>Loading DICOM metadata...</p>
                </div>
            </div>
        </div>
    </div>
</div>

<style>
.dicom-viewer-container {
    max-width: 100%;
    margin: 0;
    padding: 0;
}

.viewer-header {
    background: var(--bg-secondary);
    padding: 1rem;
    border-bottom: 1px solid var(--border-color);
    display: flex;
    justify-content: space-between;
    align-items: flex-start;
}

.viewer-info h1 {
    margin: 0 0 1rem 0;
    color: var(--text-primary);
}

.file-details {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
    gap: 0.5rem;
}

.detail-item {
    font-size: 0.875rem;
    color: var(--text-secondary);
}

.viewer-actions {
    display: flex;
    gap: 0.5rem;
}

.viewer-controls {
    background: var(--bg-secondary);
    padding: 1rem;
    border-bottom: 1px solid var(--border-color);
    display: flex;
    gap: 2rem;
    align-items: center;
    flex-wrap: wrap;
}

.control-group {
    display: flex;
    align-items: center;
    gap: 0.5rem;
}

.viewer-main {
    display: flex;
    height: calc(100vh - 200px);
}

.view-container {
    display: none;
    flex: 1;
}

.view-container.active {
    display: block;
}

.dicom-3d-container {
    width: 100%;
    height: 100%;
    background: #000;
    border-radius: 8px;
    position: relative;
}

.3d-controls {
    margin-top: 1rem;
    display: flex;
    gap: 0.5rem;
    justify-content: center;
}

.multi-view-grid {
    display: grid;
    grid-template-columns: 1fr 1fr;
    grid-template-rows: 1fr 1fr;
    gap: 1rem;
    height: 100%;
}

.view-cell {
    background: var(--bg-secondary);
    border-radius: 8px;
    padding: 1rem;
    display: flex;
    flex-direction: column;
}

.view-cell h4 {
    margin: 0 0 0.5rem 0;
    color: var(--text-primary);
    text-align: center;
}

.view-cell .dicom-image-container {
    flex: 1;
    background: #000;
    border-radius: 4px;
}

.video-controls {
    background: var(--bg-secondary);
    padding: 0.5rem;
    border-radius: 4px;
    border: 1px solid var(--border-color);
}

.view-mode-controls button.active {
    background-color: var(--primary-color);
    color: white;
}

/* Tool button states */
.viewer-controls button.active {
    background-color: var(--success-color, #28a745) !important;
    color: white !important;
    border-color: var(--success-color, #28a745) !important;
}

.viewer-controls button:hover {
    transform: translateY(-1px);
    box-shadow: 0 2px 4px rgba(0,0,0,0.1);
}

.dicom-image-container {
    flex: 1;
    background: #000;
    position: relative;
    overflow: hidden;
}

.dicom-image-container canvas {
    width: 100% !important;
    height: 100% !important;
    cursor: crosshair;
}

.viewer-sidebar {
    width: 300px;
    background: var(--bg-secondary);
    border-left: 1px solid var(--border-color);
    padding: 1rem;
    overflow-y: auto;
}

.dicom-info h3 {
    margin: 0 0 1rem 0;
    color: var(--text-primary);
}

#dicomMetadata {
    font-size: 0.875rem;
    color: var(--text-secondary);
}

#dicomMetadata p {
    margin: 0.25rem 0;
}

.image-navigation {
    display: flex;
    align-items: center;
    gap: 0.5rem;
    margin-right: 1rem;
}

.image-navigation button {
    padding: 0.5rem;
    border-radius: 50%;
    width: 40px;
    height: 40px;
    display: flex;
    align-items: center;
    justify-content: center;
    transition: all 0.2s ease;
}

.image-navigation button:hover:not(:disabled) {
    background-color: var(--primary-color);
    color: white;
    transform: scale(1.1);
}

.image-navigation button:disabled {
    opacity: 0.5;
    cursor: not-allowed;
}

.image-counter {
    font-weight: 600;
    color: var(--text-primary);
    min-width: 60px;
    text-align: center;
}

.tool-instructions {
    background: var(--bg-secondary);
    padding: 1rem;
    border-top: 1px solid var(--border-color);
    margin-top: 1rem;
    border-radius: 8px;
}

.tool-instructions details {
    border: 1px solid var(--border-color);
    border-radius: 8px;
    padding: 0.75rem;
    background: var(--bg-primary);
}

.tool-instructions summary {
    cursor: pointer;
    font-weight: 600;
    color: var(--text-primary);
    padding: 0.5rem 0;
    display: flex;
    align-items: center;
    gap: 0.5rem;
}

.tool-instructions summary i {
    color: var(--primary-color);
}

.instructions-content {
    padding-left: 1.5rem;
    font-size: 0.875rem;
    color: var(--text-secondary);
}

.instruction-item {
    margin-bottom: 0.5rem;
}

.instruction-item strong {
    color: var(--text-primary);
}

@media (max-width: 768px) {
    .viewer-main {
        flex-direction: column;
    }
    
    .viewer-sidebar {
        width: 100%;
        height: 200px;
    }
    
    .image-navigation {
        margin-right: 0.5rem;
    }
    
    .image-counter {
        font-size: 0.875rem;
        min-width: 50px;
    }
    
    .viewer-controls {
        flex-direction: column;
        gap: 1rem;
        align-items: stretch;
    }
    
    .control-group {
        justify-content: center;
    }
    
    .multi-view-grid {
        grid-template-columns: 1fr;
        grid-template-rows: repeat(3, 1fr);
    }
    
    .video-controls {
        flex-wrap: wrap;
        justify-content: center;
    }
}
</style>

<!-- Cornerstone.js Libraries -->
<script src="<?= app_url('js/cornerstone/dicomParser.min.js') ?>"></script>
<script src="<?= app_url('js/cornerstone/cornerstone.min.js') ?>"></script>
<script src="<?= app_url('js/cornerstone/cornerstoneMath.min.js') ?>"></script>
<script src="<?= app_url('js/cornerstone/cornerstoneWADOImageLoader.bundle.min.js') ?>"></script>
<script src="<?= app_url('js/cornerstone/cornerstoneTools.min.js') ?>"></script>

<script>
// Navigation data
const patientFiles = <?= json_encode($patientFiles) ?>;
const currentIndex = <?= $currentIndex ?>;
let currentImageId = <?= $fileId ?>;

// Initialize Cornerstone
    cornerstoneWADOImageLoader.external.cornerstone = cornerstone;
cornerstoneWADOImageLoader.external.cornerstoneMath = cornerstoneMath;
    cornerstoneWADOImageLoader.external.dicomParser = dicomParser;

// Configure the web worker manager
    cornerstoneWADOImageLoader.webWorkerManager.initialize({
    maxWebWorkers: navigator.hardwareConcurrency || 1,
    startWebWorkersOnDemand: true,
    taskConfiguration: {
        decodeTask: {
            initializeCodecsOnStartup: true,
            usePDFJS: false,
            strict: false
        }
    }
});

// Get the element
const element = document.getElementById('dicomImage');

// Enable the element
cornerstone.enable(element);

// Initialize CornerstoneTools after cornerstone is enabled
cornerstoneTools.init();

console.log('CornerstoneTools initialized:', cornerstoneTools);
console.log('Available tools:', Object.keys(cornerstoneTools).filter(key => key.endsWith('Tool')));

// Add tools using the correct API
cornerstoneTools.addTool(cornerstoneTools.WwwcTool);
cornerstoneTools.addTool(cornerstoneTools.ZoomTool);
cornerstoneTools.addTool(cornerstoneTools.LengthTool);
cornerstoneTools.addTool(cornerstoneTools.AngleTool);

console.log('Tools added successfully');

// Set the initial tool and configure mouse interactions
cornerstoneTools.setToolActive('Wwwc', { mouseButtonMask: 1 });
cornerstoneTools.setToolActive('Zoom', { mouseButtonMask: 2 });
cornerstoneTools.setToolActive('Length', { mouseButtonMask: 4 });
cornerstoneTools.setToolActive('Angle', { mouseButtonMask: 8 });

console.log('Tools activated with mouse button masks');

// Load the image with proper DICOM format
const imageId = 'wadouri:<?= app_url('serve_dicom.php?id=' . $fileId) ?>';

console.log('Loading image with ID:', imageId);

cornerstone.loadImage(imageId).then(function(image) {
    console.log('Image loaded successfully:', image);

    // Display the image
    cornerstone.displayImage(element, image);

    // Initialize tools properly
    cornerstoneTools.init();
    
    console.log('CornerstoneTools initialized:', cornerstoneTools);
    console.log('Available tools:', Object.keys(cornerstoneTools).filter(key => key.endsWith('Tool')));
    
    // Add tools using the correct API
    cornerstoneTools.addTool(cornerstoneTools.WwwcTool);
    cornerstoneTools.addTool(cornerstoneTools.ZoomTool);
    cornerstoneTools.addTool(cornerstoneTools.LengthTool);
    cornerstoneTools.addTool(cornerstoneTools.AngleTool);
    
    console.log('Tools added successfully');
    
    // Set the initial tool and configure mouse interactions
    cornerstoneTools.setToolActive('Wwwc', { mouseButtonMask: 1 });
    cornerstoneTools.setToolActive('Zoom', { mouseButtonMask: 2 });
    cornerstoneTools.setToolActive('Length', { mouseButtonMask: 4 });
    cornerstoneTools.setToolActive('Angle', { mouseButtonMask: 8 });
    
    console.log('Tools activated with mouse button masks');
    
    // Display DICOM metadata
    displayDicomMetadata(image);
    
    // Check for multi-frame images
    if (window.checkMultiFrame) {
        window.checkMultiFrame(image);
    }
    
    // Update navigation state
    updateNavigationState();
    
}).catch(function(error) {
    console.error('Error loading image:', error);
    document.getElementById('dicomMetadata').innerHTML = '<p style="color: red;">Error loading DICOM file: ' + error.message + '</p>';
    element.innerHTML = '<div style="color: white; text-align: center; padding-top: 100px;">Error loading DICOM file<br><small>' + error.message + '</small></div>';
});

// Tool activation
document.getElementById('windowLevel').addEventListener('click', function() {
    console.log('Window/Level button clicked');
    
    // Deactivate all tools first
    cornerstoneTools.setToolActive('Wwwc', { mouseButtonMask: 0 });
    cornerstoneTools.setToolActive('Zoom', { mouseButtonMask: 0 });
    cornerstoneTools.setToolActive('Length', { mouseButtonMask: 0 });
    cornerstoneTools.setToolActive('Angle', { mouseButtonMask: 0 });
    
    // Activate Window/Level tool
    cornerstoneTools.setToolActive('Wwwc', { mouseButtonMask: 1 });
    console.log('Window/Level tool activated');
    
    // Update button states
    updateToolButtonStates('windowLevel');
});

document.getElementById('zoom').addEventListener('click', function() {
    console.log('Zoom button clicked');
    
    // Deactivate all tools first
    cornerstoneTools.setToolActive('Wwwc', { mouseButtonMask: 0 });
    cornerstoneTools.setToolActive('Zoom', { mouseButtonMask: 0 });
    cornerstoneTools.setToolActive('Length', { mouseButtonMask: 0 });
    cornerstoneTools.setToolActive('Angle', { mouseButtonMask: 0 });
    
    // Activate Zoom tool
    cornerstoneTools.setToolActive('Zoom', { mouseButtonMask: 1 });
    console.log('Zoom tool activated');
    
    // Update button states
    updateToolButtonStates('zoom');
});

document.getElementById('length').addEventListener('click', function() {
    console.log('Length button clicked');
    
    // Deactivate all tools first
    cornerstoneTools.setToolActive('Wwwc', { mouseButtonMask: 0 });
    cornerstoneTools.setToolActive('Zoom', { mouseButtonMask: 0 });
    cornerstoneTools.setToolActive('Length', { mouseButtonMask: 0 });
    cornerstoneTools.setToolActive('Angle', { mouseButtonMask: 0 });
    
    // Activate Length tool
    cornerstoneTools.setToolActive('Length', { mouseButtonMask: 1 });
    console.log('Length tool activated');
    
    // Update button states
    updateToolButtonStates('length');
});

document.getElementById('angle').addEventListener('click', function() {
    console.log('Angle button clicked');
    
    // Deactivate all tools first
    cornerstoneTools.setToolActive('Wwwc', { mouseButtonMask: 0 });
    cornerstoneTools.setToolActive('Zoom', { mouseButtonMask: 0 });
    cornerstoneTools.setToolActive('Length', { mouseButtonMask: 0 });
    cornerstoneTools.setToolActive('Angle', { mouseButtonMask: 0 });
    
    // Activate Angle tool
    cornerstoneTools.setToolActive('Angle', { mouseButtonMask: 1 });
    console.log('Angle tool activated');
    
    // Update button states
    updateToolButtonStates('angle');
});

document.getElementById('reset').addEventListener('click', function() {
    cornerstone.reset(element);
});

// Window/Level slider
const slider = document.getElementById('windowLevelSlider');
const sliderValue = document.getElementById('windowLevelValue');

slider.addEventListener('input', function() {
    const value = this.value;
    sliderValue.textContent = value;
    
    // Get the current image
    const image = cornerstone.getImage(element);
    if (image) {
      const viewport = cornerstone.getDefaultViewportForImage(element, image);
        viewport.voi.windowWidth = image.maxPixelValue * (value / 100);
        viewport.voi.windowCenter = viewport.voi.windowWidth / 2;
        cornerstone.setViewport(element, viewport);
    }
});

function displayDicomMetadata(image) {
    const metadata = image.data;
    let html = '';
    
    if (metadata.string('x00100010')) {
        html += '<p><strong>Patient Name:</strong> ' + metadata.string('x00100010') + '</p>';
    }
    if (metadata.string('x00100020')) {
        html += '<p><strong>Patient ID:</strong> ' + metadata.string('x00100020') + '</p>';
    }
    if (metadata.string('x00080020')) {
        html += '<p><strong>Study Date:</strong> ' + metadata.string('x00080020') + '</p>';
    }
    if (metadata.string('x00080030')) {
        html += '<p><strong>Study Time:</strong> ' + metadata.string('x00080030') + '</p>';
    }
    if (metadata.string('x00080060')) {
        html += '<p><strong>Modality:</strong> ' + metadata.string('x00080060') + '</p>';
    }
    if (metadata.string('x0008103e')) {
        html += '<p><strong>Series Description:</strong> ' + metadata.string('x0008103e') + '</p>';
    }
    if (metadata.string('x00180050')) {
        html += '<p><strong>Slice Thickness:</strong> ' + metadata.string('x00180050') + ' mm</p>';
    }
    if (metadata.string('x00280030')) {
        html += '<p><strong>Pixel Spacing:</strong> ' + metadata.string('x00280030') + '</p>';
    }
    
    if (html === '') {
        html = '<p>No metadata available</p>';
    }
    
    document.getElementById('dicomMetadata').innerHTML = html;
}

// Handle window resize
window.addEventListener('resize', function() {
    cornerstone.resize(element);
});

// Navigation functions
function loadImage(fileId) {
    const imageId = 'wadouri:<?= app_url('serve_dicom.php?id=') ?>' + fileId;
    console.log('Loading image with ID:', imageId);
    
    // Clear current image
    cornerstone.disable(element);
    cornerstone.enable(element);
    
    // Load new image
    cornerstone.loadImage(imageId).then(function(image) {
        console.log('Image loaded successfully:', image);
        
        // Display the image
        cornerstone.displayImage(element, image);
        
        // Reinitialize tools
      cornerstoneTools.init();
        
        console.log('CornerstoneTools initialized:', cornerstoneTools);
        console.log('Available tools:', Object.keys(cornerstoneTools).filter(key => key.endsWith('Tool')));
        
        // Add tools
      cornerstoneTools.addTool(cornerstoneTools.WwwcTool);
      cornerstoneTools.addTool(cornerstoneTools.ZoomTool);
        cornerstoneTools.addTool(cornerstoneTools.LengthTool);
        cornerstoneTools.addTool(cornerstoneTools.AngleTool);
        
        console.log('Tools added successfully');
        
        // Set the initial tool and configure mouse interactions
        cornerstoneTools.setToolActive('Wwwc', { mouseButtonMask: 1 });
        cornerstoneTools.setToolActive('Zoom', { mouseButtonMask: 2 });
        cornerstoneTools.setToolActive('Length', { mouseButtonMask: 4 });
        cornerstoneTools.setToolActive('Angle', { mouseButtonMask: 8 });
        
        console.log('Tools activated with mouse button masks');
        
        // Display DICOM metadata
        displayDicomMetadata(image);
        
        // Check for multi-frame images
        if (window.checkMultiFrame) {
            window.checkMultiFrame(image);
        }
        
        // Update navigation state
        updateNavigationState();
        
    }).catch(function(error) {
        console.error('Error loading image:', error);
        document.getElementById('dicomMetadata').innerHTML = '<p style="color: red;">Error loading DICOM file: ' + error.message + '</p>';
        element.innerHTML = '<div style="color: white; text-align: center; padding-top: 100px;">Error loading DICOM file<br><small>' + error.message + '</small></div>';
    });
}

// Function to update tool button states
function updateToolButtonStates(activeToolId) {
    const toolButtons = ['windowLevel', 'zoom', 'length', 'angle'];
    
    toolButtons.forEach(buttonId => {
        const button = document.getElementById(buttonId);
        if (button) {
            if (buttonId === activeToolId) {
                button.classList.add('active');
                button.classList.remove('btn-primary');
                button.classList.add('btn-success');
            } else {
                button.classList.remove('active');
                button.classList.remove('btn-success');
                button.classList.add('btn-primary');
            }
        }
    });
}

// Initialize tool button states on page load
document.addEventListener('DOMContentLoaded', function() {
    // Set initial tool button state
    updateToolButtonStates('windowLevel');
});

function updateNavigationState() {
    const prevBtn = document.getElementById('prevImage');
    const nextBtn = document.getElementById('nextImage');
    const counter = document.querySelector('.image-counter');
    
    if (prevBtn && nextBtn && counter) {
        prevBtn.disabled = currentIndex === 0;
        nextBtn.disabled = currentIndex === (patientFiles.length - 1);
        counter.textContent = (currentIndex + 1) + ' of ' + patientFiles.length;
    }
}

function navigateToImage(direction) {
    if (direction === 'prev' && currentIndex > 0) {
        currentIndex--;
    } else if (direction === 'next' && currentIndex < patientFiles.length - 1) {
        currentIndex++;
    } else {
        return;
    }
    
    const newFile = patientFiles[currentIndex];
    currentImageId = newFile.id;
    
    // Update URL without page reload
    const newUrl = new URL(window.location);
    newUrl.searchParams.set('id', newFile.id);
    window.history.pushState({}, '', newUrl);
    
    // Load the new image
    loadImage(newFile.id);
}

// Navigation event listeners
document.addEventListener('DOMContentLoaded', function() {
    const prevBtn = document.getElementById('prevImage');
    const nextBtn = document.getElementById('nextImage');
    
    if (prevBtn) {
        prevBtn.addEventListener('click', function() {
            navigateToImage('prev');
        });
    }
    
    if (nextBtn) {
        nextBtn.addEventListener('click', function() {
            navigateToImage('next');
        });
    }
    
    // Initialize navigation state
    updateNavigationState();
    
    // Add keyboard navigation
    document.addEventListener('keydown', function(e) {
        if (e.target.tagName === 'INPUT' || e.target.tagName === 'TEXTAREA') {
            return; // Don't interfere with form inputs
        }
        
        switch(e.key) {
            case 'ArrowLeft':
                if (currentIndex > 0) {
                    navigateToImage('prev');
                }
                break;
            case 'ArrowRight':
                if (currentIndex < patientFiles.length - 1) {
                    navigateToImage('next');
                }
                break;
        }
    });
    
    // Initialize view mode controls
    initializeViewModes();
    
    // Initialize video controls (temporarily disabled)
    // initializeVideoControls();
    
    // Initialize 3D controls (temporarily disabled)
    // initialize3DControls();
});

// View Mode Functions
function initializeViewModes() {
    const view2DBtn = document.getElementById('view2D');
    const view3DBtn = document.getElementById('view3D');
    const viewMultiBtn = document.getElementById('viewMulti');
    
    const view2DContainer = document.getElementById('view2DContainer');
    const view3DContainer = document.getElementById('view3DContainer');
    const viewMultiContainer = document.getElementById('viewMultiContainer');
    
    function switchView(activeContainer, activeBtn) {
        // Hide all containers
        [view2DContainer, view3DContainer, viewMultiContainer].forEach(container => {
            container.classList.remove('active');
        });
        
        // Remove active class from all buttons
        [view2DBtn, view3DBtn, viewMultiBtn].forEach(btn => {
            btn.classList.remove('active');
        });
        
        // Show active container and button
        activeContainer.classList.add('active');
        activeBtn.classList.add('active');
    }
    
    // Only enable 2D view for now
    view2DBtn.addEventListener('click', () => switchView(view2DContainer, view2DBtn));
    
    // 3D and Multi-view are disabled for now
    view3DBtn.addEventListener('click', () => {
        alert('3D view is coming soon! This will include volume rendering and 3D navigation.');
    });
    
    viewMultiBtn.addEventListener('click', () => {
        alert('Multi-view is coming soon! This will include axial, sagittal, and coronal views.');
    });
}

// Video Control Functions
function initializeVideoControls() {
    const playPauseBtn = document.getElementById('playPause');
    const stopBtn = document.getElementById('stop');
    const frameSlider = document.getElementById('frameSlider');
    const frameCounter = document.getElementById('frameCounter');
    const frameRateInput = document.getElementById('frameRate');
    const videoControls = document.getElementById('videoControls');
    
    let isPlaying = false;
    let animationId = null;
    let currentFrame = 0;
    let totalFrames = 1;
    let frameRate = 10;
    
    // Check if current image has multiple frames
    function checkMultiFrame(image) {
        if (image && image.data && image.data.uint16) {
            const rows = image.rows;
            const columns = image.columns;
            const numberOfFrames = image.data.uint16('x00280008') || 1;
            
            if (numberOfFrames > 1) {
                totalFrames = numberOfFrames;
                frameSlider.max = numberOfFrames - 1;
                videoControls.style.display = 'flex';
                return true;
            }
        }
        videoControls.style.display = 'none';
        return false;
    }
    
    // Play/Pause functionality
    playPauseBtn.addEventListener('click', function() {
        if (isPlaying) {
            pauseVideo();
        } else {
            playVideo();
        }
    });
    
    function playVideo() {
        if (totalFrames <= 1) return;
        
        isPlaying = true;
        playPauseBtn.innerHTML = '<i class="fas fa-pause"></i> Pause';
        playPauseBtn.classList.remove('btn-success');
        playPauseBtn.classList.add('btn-warning');
        
        function animate() {
            if (!isPlaying) return;
            
            currentFrame = (currentFrame + 1) % totalFrames;
            frameSlider.value = currentFrame;
            frameCounter.textContent = `Frame ${currentFrame + 1}`;
            
            // Update image to current frame
            updateImageFrame(currentFrame);
            
            animationId = setTimeout(animate, 1000 / frameRate);
        }
        
        animate();
    }
    
    function pauseVideo() {
        isPlaying = false;
        playPauseBtn.innerHTML = '<i class="fas fa-play"></i> Play';
        playPauseBtn.classList.remove('btn-warning');
        playPauseBtn.classList.add('btn-success');
        
        if (animationId) {
            clearTimeout(animationId);
            animationId = null;
        }
    }
    
    // Stop functionality
    stopBtn.addEventListener('click', function() {
        pauseVideo();
        currentFrame = 0;
        frameSlider.value = 0;
        frameCounter.textContent = 'Frame 1';
        updateImageFrame(0);
    });
    
    // Frame slider
    frameSlider.addEventListener('input', function() {
        currentFrame = parseInt(this.value);
        frameCounter.textContent = `Frame ${currentFrame + 1}`;
        updateImageFrame(currentFrame);
    });
    
    // Frame rate input
    frameRateInput.addEventListener('change', function() {
        frameRate = parseInt(this.value);
        if (isPlaying) {
            pauseVideo();
            playVideo();
        }
    });
    
    // Update image frame (placeholder - would need Cornerstone.js multi-frame support)
    function updateImageFrame(frameIndex) {
        console.log(`Switching to frame ${frameIndex + 1}`);
        // This would need to be implemented with Cornerstone.js multi-frame support
        // For now, it's a placeholder that logs the frame change
    }
    
    // Check for multi-frame when image loads
    window.checkMultiFrame = checkMultiFrame;
}

// 3D Control Functions
function initialize3DControls() {
    const rotateLeftBtn = document.getElementById('rotateLeft');
    const rotateRightBtn = document.getElementById('rotateRight');
    const reset3DBtn = document.getElementById('reset3D');
    
    let rotationAngle = 0;
    let elevationAngle = 0;
    
    if (rotateLeftBtn) {
        rotateLeftBtn.addEventListener('click', function() {
            rotationAngle -= 15;
            update3DView();
        });
    }
    
    if (rotateRightBtn) {
        rotateRightBtn.addEventListener('click', function() {
            rotationAngle += 15;
            update3DView();
        });
    }
    
    if (reset3DBtn) {
        reset3DBtn.addEventListener('click', function() {
            rotationAngle = 0;
            elevationAngle = 0;
            update3DView();
        });
    }
    
    function update3DView() {
        const container = document.getElementById('dicom3D');
        if (container) {
            // This is a placeholder for 3D rendering
            // In a real implementation, you would use a 3D library like Three.js
            container.innerHTML = `
                <div style="color: white; text-align: center; padding-top: 100px;">
                    <h3>3D View</h3>
                    <p>Rotation: ${rotationAngle}°</p>
                    <p>Elevation: ${elevationAngle}°</p>
                    <p><small>3D rendering requires additional libraries (Three.js, etc.)</small></p>
                </div>
            `;
        }
    }
    
    // Initialize 3D view
    update3DView();
}
</script>

<?php
function formatBytes($bytes, $precision = 2) {
    $units = array('B', 'KB', 'MB', 'GB', 'TB');
    for ($i = 0; $bytes > 1024 && $i < count($units) - 1; $i++) {
        $bytes /= 1024;
    }
    return round($bytes, $precision) . ' ' . $units[$i];
}
?>

<?php include __DIR__ . '/partials/footer.php'; ?>

