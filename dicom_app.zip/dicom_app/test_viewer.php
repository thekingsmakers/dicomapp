<?php
declare(strict_types=1);

require_once __DIR__ . '/config.php';
require_once __DIR__ . '/lib/auth.php';
require_once __DIR__ . '/lib/db.php';

// Simple test without authentication for debugging
echo "<h1>DICOM Viewer Test</h1>";

// Check if we have any DICOM files in the database
$stmt = db()->prepare("SELECT df.id, df.file_path, df.original_filename, p.mrn 
                       FROM dicom_files df 
                       JOIN patients p ON p.id = df.patient_id 
                       LIMIT 1");
$stmt->execute();
$file = $stmt->fetch();

if (!$file) {
    echo "<p>No DICOM files found in database.</p>";
    echo "<p>Please upload some DICOM files first.</p>";
} else {
    echo "<h2>Testing with file ID: {$file['id']}</h2>";
    echo "<p><strong>MRN:</strong> {$file['mrn']}</p>";
    echo "<p><strong>Filename:</strong> {$file['original_filename']}</p>";
    
    // Test the serve URL
    $serveUrl = app_url('serve_dicom.php?id=' . $file['id']);
    echo "<p><strong>Serve URL:</strong> <a href='{$serveUrl}' target='_blank'>{$serveUrl}</a></p>";
    
    // Test basic Cornerstone.js functionality
    echo "<h2>Cornerstone.js Test</h2>";
    echo "<div id='testViewer' style='width: 600px; height: 400px; background: #000; border: 1px solid #ccc; margin: 1rem 0;'></div>";
    
    echo "<div style='margin: 1rem 0;'>";
    echo "<button onclick='testBasicFunctionality()'>Test Basic Functionality</button> ";
    echo "<button onclick='testTools()'>Test Tools</button> ";
    echo "<button onclick='testMultiFrame()'>Test Multi-Frame</button>";
    echo "</div>";
    
    echo "<div id='testResults' style='background: #f8f9fa; padding: 1rem; border-radius: 4px; margin: 1rem 0;'>";
    echo "<h3>Test Results:</h3>";
    echo "<div id='results'>Click a test button to start...</div>";
    echo "</div>";
}

echo "<h2>System Information</h2>";
echo "<ul>";
echo "<li><strong>PHP Version:</strong> " . PHP_VERSION . "</li>";
echo "<li><strong>Memory Limit:</strong> " . ini_get('memory_limit') . "</li>";
echo "<li><strong>Max Upload Size:</strong> " . ini_get('upload_max_filesize') . "</li>";
echo "</ul>";
?>

<!-- Cornerstone.js Libraries -->
<script src="<?= app_url('js/cornerstone/dicomParser.min.js') ?>"></script>
<script src="<?= app_url('js/cornerstone/cornerstone.min.js') ?>"></script>
<script src="<?= app_url('js/cornerstone/cornerstoneMath.min.js') ?>"></script>
<script src="<?= app_url('js/cornerstone/cornerstoneWADOImageLoader.bundle.min.js') ?>"></script>
<script src="<?= app_url('js/cornerstone/cornerstoneTools.min.js') ?>"></script>

<script>
let testElement;
let testImage;

function logResult(message, type = 'info') {
    const results = document.getElementById('results');
    const timestamp = new Date().toLocaleTimeString();
    const color = type === 'error' ? 'red' : type === 'success' ? 'green' : 'blue';
    results.innerHTML += `<p style="color: ${color}; margin: 0.25rem 0;"><strong>[${timestamp}]</strong> ${message}</p>`;
    results.scrollTop = results.scrollHeight;
}

function testBasicFunctionality() {
    logResult('Starting basic functionality test...');
    
    try {
        // Check if libraries are loaded
        if (typeof cornerstone === 'undefined') {
            throw new Error('Cornerstone not loaded');
        }
        if (typeof cornerstoneWADOImageLoader === 'undefined') {
            throw new Error('CornerstoneWADOImageLoader not loaded');
        }
        if (typeof cornerstoneTools === 'undefined') {
            throw new Error('CornerstoneTools not loaded');
        }
        
        logResult('✓ All libraries loaded successfully', 'success');
        
        // Initialize
        cornerstoneWADOImageLoader.external.cornerstone = cornerstone;
        cornerstoneWADOImageLoader.external.cornerstoneMath = cornerstoneMath;
        cornerstoneWADOImageLoader.external.dicomParser = dicomParser;
        
        logResult('✓ External libraries configured', 'success');
        
        // Configure web workers
        cornerstoneWADOImageLoader.webWorkerManager.initialize({
            maxWebWorkers: 1,
            startWebWorkersOnDemand: true
        });
        
        logResult('✓ Web worker manager initialized', 'success');
        
        // Get and enable element
        testElement = document.getElementById('testViewer');
        cornerstone.enable(testElement);
        
        logResult('✓ Element enabled', 'success');
        
        // Load test image
        const imageId = 'wadouri:<?= app_url('serve_dicom.php?id=' . ($file['id'] ?? 1)) ?>';
        logResult(`Loading image: ${imageId}`);
        
        cornerstone.loadImage(imageId).then(function(image) {
            testImage = image;
            logResult('✓ Image loaded successfully', 'success');
            logResult(`Image dimensions: ${image.columns} x ${image.rows}`, 'info');
            
            // Display image
            cornerstone.displayImage(testElement, image);
            logResult('✓ Image displayed', 'success');
            
        }).catch(function(error) {
            logResult(`✗ Error loading image: ${error.message}`, 'error');
        });
        
    } catch (error) {
        logResult(`✗ Test failed: ${error.message}`, 'error');
    }
}

function testTools() {
    logResult('Starting tools test...');
    
    if (!testElement || !testImage) {
        logResult('✗ Please run basic functionality test first', 'error');
        return;
    }
    
    try {
        // Initialize tools
        cornerstoneTools.init();
        logResult('✓ Tools initialized', 'success');
        
        // Check available tools
        const availableTools = Object.keys(cornerstoneTools).filter(key => key.endsWith('Tool'));
        logResult(`Available tools: ${availableTools.join(', ')}`, 'info');
        
        // Try to add a basic tool
        if (cornerstoneTools.WwwcTool) {
            cornerstoneTools.addTool(cornerstoneTools.WwwcTool);
            cornerstoneTools.setToolActive('Wwwc', { mouseButtonMask: 1 });
            logResult('✓ Window/Level tool activated', 'success');
        } else {
            logResult('✗ WwwcTool not available', 'error');
        }
        
    } catch (error) {
        logResult(`✗ Tools test failed: ${error.message}`, 'error');
    }
}

function testMultiFrame() {
    logResult('Starting multi-frame test...');
    
    if (!testImage) {
        logResult('✗ Please run basic functionality test first', 'error');
        return;
    }
    
    try {
        // Check for multi-frame data
        if (testImage.data && testImage.data.uint16) {
            const numberOfFrames = testImage.data.uint16('x00280008') || 1;
            logResult(`Number of frames: ${numberOfFrames}`, 'info');
            
            if (numberOfFrames > 1) {
                logResult('✓ Multi-frame DICOM detected', 'success');
                
                // Check other relevant tags
                const rows = testImage.rows;
                const columns = testImage.columns;
                logResult(`Image dimensions: ${columns} x ${rows}`, 'info');
                
            } else {
                logResult('Single frame DICOM (no video)', 'info');
            }
        } else {
            logResult('✗ No DICOM data available', 'error');
        }
        
    } catch (error) {
        logResult(`✗ Multi-frame test failed: ${error.message}`, 'error');
    }
}

// Auto-run basic test when page loads
window.addEventListener('load', function() {
    setTimeout(testBasicFunctionality, 1000);
});
</script>
