// Upload functionality for DICOM files
document.addEventListener('DOMContentLoaded', function() {
    const uploadArea = document.getElementById('uploadArea');
    const fileInput = document.getElementById('files');
    const fileList = document.getElementById('fileList');

    if (!uploadArea || !fileInput || !fileList) {
        console.error('Upload elements not found');
        return;
    }

    // Click to browse files
    uploadArea.addEventListener('click', function(e) {
        // Don't trigger if clicking on the file input itself
        if (e.target !== fileInput) {
            fileInput.click();
        }
    });

    // Drag and drop events
    uploadArea.addEventListener('dragover', function(e) {
        e.preventDefault();
        uploadArea.classList.add('dragover');
    });

    uploadArea.addEventListener('dragleave', function(e) {
        e.preventDefault();
        uploadArea.classList.remove('dragover');
    });

    uploadArea.addEventListener('drop', function(e) {
        e.preventDefault();
        uploadArea.classList.remove('dragover');
        
        if (e.dataTransfer.files) {
            fileInput.files = e.dataTransfer.files;
            updateFileList();
        }
    });

    // File input change event
    fileInput.addEventListener('change', updateFileList);

    function updateFileList() {
        fileList.innerHTML = '';
        const files = fileInput.files;
        
        if (files && files.length > 0) {
            const list = document.createElement('ul');
            list.style.listStyle = 'none';
            list.style.padding = '0';
            
            for (let file of files) {
                const li = document.createElement('li');
                li.style.padding = '0.5rem';
                li.style.margin = '0.25rem 0';
                li.style.background = '#f8fafc';
                li.style.borderRadius = '4px';
                li.style.fontSize = '0.875rem';
                li.innerHTML = `<i class="fas fa-file-medical"></i> ${file.name} (${formatBytes(file.size)})`;
                list.appendChild(li);
            }
            
            fileList.appendChild(list);
        }
    }

    function formatBytes(bytes, decimals = 2) {
        if (bytes === 0) return '0 Bytes';
        const k = 1024;
        const dm = decimals < 0 ? 0 : decimals;
        const sizes = ['Bytes', 'KB', 'MB', 'GB', 'TB'];
        const i = Math.floor(Math.log(bytes) / Math.log(k));
        return parseFloat((bytes / Math.pow(k, i)).toFixed(dm)) + ' ' + sizes[i];
    }

    // Debug info
    console.log('Upload functionality initialized');
    console.log('Upload area:', uploadArea);
    console.log('File input:', fileInput);
    console.log('File list:', fileList);
});

// Global function for browse button
function browseFiles() {
    const fileInput = document.getElementById('files');
    if (fileInput) {
        fileInput.click();
    }
}
