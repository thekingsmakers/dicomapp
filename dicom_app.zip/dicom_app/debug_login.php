<?php
declare(strict_types=1);

// Test database connection and authentication
echo "<h2>DICOM App Login Debug</h2>";

// Test 1: Database Connection
echo "<h3>1. Testing Database Connection</h3>";
try {
    $dsn = 'mysql:host=localhost;port=3306;dbname=dicom_app;charset=utf8mb4';
    $user = 'admin';
    $pass = 'G@ngstar36';
    
    $pdo = new PDO($dsn, $user, $pass, [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    ]);
    
    echo "✅ Database connection successful<br>";
    
    // Test 2: Check if users table exists
    echo "<h3>2. Checking Users Table</h3>";
    $stmt = $pdo->query("SHOW TABLES LIKE 'users'");
    if ($stmt->rowCount() > 0) {
        echo "✅ Users table exists<br>";
        
        // Test 3: Check users in database
        echo "<h3>3. Checking Users in Database</h3>";
        $stmt = $pdo->query("SELECT id, username, role FROM users");
        $users = $stmt->fetchAll();
        
        if (count($users) > 0) {
            echo "✅ Found " . count($users) . " users:<br>";
            foreach ($users as $user) {
                echo "- ID: {$user['id']}, Username: {$user['username']}, Role: {$user['role']}<br>";
            }
        } else {
            echo "❌ No users found in database<br>";
        }
        
        // Test 4: Test admin user authentication
        echo "<h3>4. Testing Admin Authentication</h3>";
        $stmt = $pdo->prepare("SELECT id, username, password_hash, role FROM users WHERE username = ? LIMIT 1");
        $stmt->execute(['admin']);
        $admin = $stmt->fetch();
        
        if ($admin) {
            echo "✅ Admin user found<br>";
            echo "Password hash: " . substr($admin['password_hash'], 0, 20) . "...<br>";
            
            // Test password verification
            $test_password = 'Admin@123';
            if (password_verify($test_password, $admin['password_hash'])) {
                echo "✅ Password 'Admin@123' is correct<br>";
            } else {
                echo "❌ Password 'Admin@123' is incorrect<br>";
                echo "Trying to create new admin user...<br>";
                
                // Create new admin user
                $new_password_hash = password_hash('Admin@123', PASSWORD_DEFAULT);
                $stmt = $pdo->prepare("UPDATE users SET password_hash = ? WHERE username = 'admin'");
                $stmt->execute([$new_password_hash]);
                echo "✅ Updated admin password<br>";
            }
        } else {
            echo "❌ Admin user not found<br>";
            echo "Creating admin user...<br>";
            
            $password_hash = password_hash('Admin@123', PASSWORD_DEFAULT);
            $stmt = $pdo->prepare("INSERT INTO users (username, password_hash, role) VALUES (?, ?, ?)");
            $stmt->execute(['admin', $password_hash, 'admin']);
            echo "✅ Created admin user with password 'Admin@123'<br>";
        }
        
    } else {
        echo "❌ Users table does not exist<br>";
        echo "Please run the db.sql script to create the database schema<br>";
    }
    
} catch (PDOException $e) {
    echo "❌ Database connection failed: " . $e->getMessage() . "<br>";
}

// Test 5: Session functionality
echo "<h3>5. Testing Session Functionality</h3>";
if (session_status() !== PHP_SESSION_ACTIVE) {
    session_start();
}
echo "✅ Session started<br>";

// Test 6: Check if login.php is accessible
echo "<h3>6. Testing Login Page Accessibility</h3>";
if (file_exists('login.php')) {
    echo "✅ login.php exists<br>";
} else {
    echo "❌ login.php not found<br>";
}

echo "<h3>7. Login Instructions</h3>";
echo "Try logging in with:<br>";
echo "- Username: admin<br>";
echo "- Password: Admin@123<br>";
echo "<br><a href='login.php'>Go to Login Page</a>";
?>
