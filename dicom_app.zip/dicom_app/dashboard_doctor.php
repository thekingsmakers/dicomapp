<?php
declare(strict_types=1);

require_once __DIR__ . '/config.php';
require_once __DIR__ . '/lib/auth.php';
require_once __DIR__ . '/lib/db.php';

require_role('doctor');
$user = current_user();

// Fetch statistics for this doctor
$stmt = db()->prepare('SELECT COUNT(*) FROM dicom_files WHERE assigned_doctor = ?');
$stmt->execute([$user['id']]);
$totalStudies = $stmt->fetchColumn();

$stmt = db()->prepare('SELECT COUNT(*) FROM dicom_files WHERE assigned_doctor = ? AND upload_date >= DATE_SUB(NOW(), INTERVAL 7 DAY)');
$stmt->execute([$user['id']]);
$recentStudies = $stmt->fetchColumn();

$stmt = db()->prepare('SELECT COUNT(DISTINCT p.id) FROM dicom_files df JOIN patients p ON p.id = df.patient_id WHERE df.assigned_doctor = ?');
$stmt->execute([$user['id']]);
$totalPatients = $stmt->fetchColumn();

$stats = [
    'total_studies' => (int)$totalStudies,
    'recent_studies' => (int)$recentStudies,
    'total_patients' => (int)$totalPatients
];

$where = ['df.assigned_doctor = ?'];
$params = [$user['id']];
if (!empty($_GET['mrn'])) {
    $where[] = 'p.mrn LIKE ?';
    $params[] = '%' . $_GET['mrn'] . '%';
}
$whereSql = 'WHERE ' . implode(' AND ', $where);

$stmt = db()->prepare("SELECT df.id, df.file_path, df.upload_date, df.original_filename, df.file_size, p.mrn, u.username AS uploader_name
FROM dicom_files df 
JOIN patients p ON p.id = df.patient_id
LEFT JOIN users u ON u.id = df.uploaded_by
$whereSql
ORDER BY df.upload_date DESC LIMIT 500");
$stmt->execute($params);
$studies = $stmt->fetchAll();

include __DIR__ . '/partials/header.php';
?>

<div class="dashboard-header">
    <h1><i class="fas fa-user-md"></i> Doctor Dashboard</h1>
    <p>Welcome back, Dr. <?= htmlspecialchars($user['username']) ?>! Manage your assigned studies and patient cases.</p>
</div>

<!-- Statistics Cards -->
<div class="dashboard-stats">
    <div class="stat-card">
        <div class="stat-number"><?= number_format($stats['total_studies']) ?></div>
        <div class="stat-label">Total Studies</div>
    </div>
    <div class="stat-card">
        <div class="stat-number"><?= number_format($stats['recent_studies']) ?></div>
        <div class="stat-label">This Week</div>
    </div>
    <div class="stat-card">
        <div class="stat-number"><?= number_format($stats['total_patients']) ?></div>
        <div class="stat-label">Patients</div>
    </div>
</div>

<!-- Studies Management Section -->
<div class="card">
    <div class="card-header">
        <h2><i class="fas fa-file-medical"></i> My Studies</h2>
    </div>
    <div class="card-body">
        <!-- Filters -->
        <div class="filters">
            <h3><i class="fas fa-filter"></i> Search Studies</h3>
            <form method="get" class="filters-grid">
                <div class="form-row">
                    <label for="mrn">Patient MRN</label>
                    <input type="text" id="mrn" name="mrn" value="<?= htmlspecialchars($_GET['mrn'] ?? '') ?>" placeholder="Search by patient MRN">
                </div>
                
                <div class="filters-actions">
                    <button type="submit" class="btn btn-primary">
                        <i class="fas fa-search"></i> Search
                    </button>
                    <a href="<?= htmlspecialchars(app_url('dashboard_doctor.php')) ?>" class="btn btn-secondary">
                        <i class="fas fa-times"></i> Clear
                    </a>
                </div>
            </form>
        </div>

        <!-- Studies Table -->
        <div class="table-container">
            <table class="table">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Patient MRN</th>
                        <th>Filename</th>
                        <th>File Size</th>
                        <th>Upload Date</th>
                        <th>Uploaded By</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                <?php if (empty($studies)): ?>
                    <tr>
                        <td colspan="7" class="empty-state">
                            <div class="empty-state-icon">📋</div>
                            <h3>No studies assigned</h3>
                            <p>You don't have any studies assigned to you yet. Contact an administrator to get studies assigned.</p>
                        </td>
                    </tr>
                <?php else: ?>
                    <?php foreach ($studies as $s): ?>
                        <tr>
                            <td><strong>#<?= (int)$s['id'] ?></strong></td>
                            <td>
                                <span class="badge badge-info"><?= htmlspecialchars($s['mrn']) ?></span>
                            </td>
                            <td><?= htmlspecialchars($s['original_filename'] ?? 'Unknown') ?></td>
                            <td><?= $s['file_size'] ? formatBytes($s['file_size']) : '—' ?></td>
                            <td><?= date('M j, Y g:i A', strtotime($s['upload_date'])) ?></td>
                            <td>
                                <?php if ($s['uploader_name']): ?>
                                    <span class="badge badge-secondary"><?= htmlspecialchars($s['uploader_name']) ?></span>
                                <?php else: ?>
                                    <span class="badge badge-warning">Unknown</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <div class="actions">
                                    <a href="<?= htmlspecialchars(app_url('view_dicom.php?id=' . (int)$s['id'])) ?>" class="btn btn-primary" title="View Study">
                                        <i class="fas fa-eye"></i> View
                                    </a>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- Quick Actions -->
<div class="card">
    <div class="card-header">
        <h2><i class="fas fa-bolt"></i> Quick Actions</h2>
    </div>
    <div class="card-body">
        <div class="actions">
            <a href="<?= htmlspecialchars(app_url('dashboard_doctor.php')) ?>" class="btn btn-primary">
                <i class="fas fa-refresh"></i> Refresh Studies
            </a>
            <a href="<?= htmlspecialchars(app_url('logout.php')) ?>" class="btn btn-secondary">
                <i class="fas fa-sign-out-alt"></i> Logout
            </a>
        </div>
    </div>
</div>

<?php
function formatBytes($bytes, $precision = 2) {
    $units = array('B', 'KB', 'MB', 'GB', 'TB');
    for ($i = 0; $bytes > 1024 && $i < count($units) - 1; $i++) {
        $bytes /= 1024;
    }
    return round($bytes, $precision) . ' ' . $units[$i];
}
?>

<?php include __DIR__ . '/partials/footer.php'; ?>

