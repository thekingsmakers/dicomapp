<?php
declare(strict_types=1);

require_once __DIR__ . '/config.php';

echo "<h2>Create Test User</h2>";

try {
    // Connect to database
    $pdo = new PDO($DB_DSN, $DB_USER, $DB_PASS, [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    ]);
    
    echo "✅ Database connection successful<br><br>";
    
    // Define the test user
    $testUser = [
        'username' => 'rayan',
        'password' => 'Admin@123',
        'role' => 'admin'  // You can change this to 'admin', 'doctor', or 'uploader'
    ];
    
    echo "<h3>Creating Test User:</h3>";
    echo "Username: " . $testUser['username'] . "<br>";
    echo "Password: " . $testUser['password'] . "<br>";
    echo "Role: " . $testUser['role'] . "<br><br>";
    
    // Check if user already exists
    $stmt = $pdo->prepare("SELECT id FROM users WHERE username = ?");
    $stmt->execute([$testUser['username']]);
    $existingUser = $stmt->fetch();
    
    if ($existingUser) {
        // Update existing user
        $passwordHash = password_hash($testUser['password'], PASSWORD_DEFAULT);
        $stmt = $pdo->prepare("UPDATE users SET password_hash = ?, role = ? WHERE username = ?");
        $stmt->execute([$passwordHash, $testUser['role'], $testUser['username']]);
        echo "✅ Updated existing user: {$testUser['username']}<br>";
    } else {
        // Create new user
        $passwordHash = password_hash($testUser['password'], PASSWORD_DEFAULT);
        $stmt = $pdo->prepare("INSERT INTO users (username, password_hash, role) VALUES (?, ?, ?)");
        $stmt->execute([$testUser['username'], $passwordHash, $testUser['role']]);
        echo "✅ Created new user: {$testUser['username']}<br>";
    }
    
    echo "<br><h3>Test User Created Successfully!</h3>";
    echo "<div style='background: #e8f5e8; padding: 15px; border: 1px solid #4caf50; border-radius: 5px;'>";
    echo "<strong>Login Credentials:</strong><br>";
    echo "Username: <strong>{$testUser['username']}</strong><br>";
    echo "Password: <strong>{$testUser['password']}</strong><br>";
    echo "Role: <strong>{$testUser['role']}</strong><br>";
    echo "</div>";
    
    echo "<br><h3>All Users in Database:</h3>";
    $stmt = $pdo->query("SELECT id, username, role FROM users ORDER BY username");
    $allUsers = $stmt->fetchAll();
    
    if (count($allUsers) > 0) {
        echo "<table border='1' style='border-collapse: collapse; width: 100%;'>";
        echo "<tr><th>ID</th><th>Username</th><th>Role</th></tr>";
        foreach ($allUsers as $user) {
            echo "<tr>";
            echo "<td>{$user['id']}</td>";
            echo "<td>{$user['username']}</td>";
            echo "<td>{$user['role']}</td>";
            echo "</tr>";
        }
        echo "</table>";
    }
    
    echo "<br><h3>Next Steps:</h3>";
    echo "1. <a href='login.php'>Go to Login Page</a><br>";
    echo "2. Use the credentials above to log in<br>";
    echo "3. You should be redirected to dashboard_{$testUser['role']}.php<br>";
    
} catch (PDOException $e) {
    echo "❌ Database error: " . $e->getMessage() . "<br>";
}
?>
