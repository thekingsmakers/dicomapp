<!DOCTYPE html>
<html>
<head>
    <title>Cornerstone.js Test</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 20px; }
        .test-container { max-width: 800px; margin: 0 auto; }
        .dicom-container { 
            width: 100%; 
            height: 400px; 
            background: #000; 
            margin: 20px 0;
            border: 1px solid #ccc;
        }
        .status { padding: 10px; margin: 10px 0; border-radius: 4px; }
        .success { background: #d4edda; color: #155724; border: 1px solid #c3e6cb; }
        .error { background: #f8d7da; color: #721c24; border: 1px solid #f5c6cb; }
        .info { background: #d1ecf1; color: #0c5460; border: 1px solid #bee5eb; }
    </style>
</head>
<body>
    <div class="test-container">
        <h1>Cornerstone.js Integration Test</h1>
        
        <div id="status" class="status info">
            Testing Cornerstone.js libraries...
        </div>
        
        <div class="dicom-container" id="dicomImage"></div>
        
        <div>
            <h3>Test Instructions:</h3>
            <ol>
                <li>Check if Cornerstone.js libraries load without errors</li>
                <li>Try to load a sample DICOM file</li>
                <li>Test basic viewer functionality</li>
            </ol>
        </div>
    </div>

    <!-- Cornerstone.js Libraries -->
    <script src="js/cornerstone/cornerstone.min.js"></script>
    <script src="js/cornerstone/cornerstoneMath.min.js"></script>
    <script src="js/cornerstone/cornerstoneTools.min.js"></script>
    <script src="js/cornerstone/cornerstoneWADOImageLoader.bundle.min.js"></script>

    <script>
        const statusDiv = document.getElementById('status');
        const element = document.getElementById('dicomImage');
        
        function updateStatus(message, type = 'info') {
            statusDiv.className = `status ${type}`;
            statusDiv.textContent = message;
        }
        
        try {
            // Test if libraries are loaded
            if (typeof cornerstone === 'undefined') {
                throw new Error('Cornerstone core not loaded');
            }
            if (typeof cornerstoneWADOImageLoader === 'undefined') {
                throw new Error('Cornerstone WADO Image Loader not loaded');
            }
            if (typeof cornerstoneTools === 'undefined') {
                throw new Error('Cornerstone Tools not loaded');
            }
            
            updateStatus('✅ All Cornerstone.js libraries loaded successfully!', 'success');
            
            // Initialize Cornerstone
            cornerstoneWADOImageLoader.external.cornerstone = cornerstone;
            cornerstoneWADOImageLoader.external.cornerstoneMath = cornerstoneMath;
            
            // Enable the element
            cornerstone.enable(element);
            
            updateStatus('✅ Cornerstone.js initialized successfully! Ready to load DICOM files.', 'success');
            
            // Test with a sample image (you can replace this with a real DICOM file)
            // For now, we'll just show that the viewer is ready
            element.innerHTML = '<div style="color: white; text-align: center; padding-top: 180px;">DICOM Viewer Ready<br><small>Upload a DICOM file to test</small></div>';
            
        } catch (error) {
            updateStatus('❌ Error: ' + error.message, 'error');
            console.error('Cornerstone.js test error:', error);
        }
    </script>
</body>
</html>
