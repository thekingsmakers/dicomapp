<?php
declare(strict_types=1);

// This page is intentionally a thin wrapper to guide users to the uploader dashboard.
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/lib/auth.php';

require_login();
$u = current_user();
if ($u['role'] !== 'uploader') {
    header('Location: ' . app_url('login.php'));
    exit;
}
header('Location: ' . app_url('dashboard_uploader.php'));
exit;


