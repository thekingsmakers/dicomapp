# DICOM App Login Troubleshooting Guide

## Issue: Unable to login to dashboards even after verifying database connection

### Step 1: Run Database Setup
First, ensure your database is properly configured with the correct users:

1. Open your web browser and navigate to: `http://localhost/dicom_app/setup_database.php`
2. This script will:
   - Test database connection
   - Create the database schema if needed
   - Set up default users with correct passwords
   - Display all users in the database

### Step 2: Test Session and Authentication
Check if sessions and authentication are working:

1. Navigate to: `http://localhost/dicom_app/test_session.php`
2. This will test:
   - Session functionality
   - Current user status
   - Database connection
   - Login attempts

### Step 3: Debug Login Process
Use the debug script to identify specific issues:

1. Navigate to: `http://localhost/dicom_app/debug_login.php`
2. This will provide detailed information about:
   - Database connection status
   - User table existence
   - User authentication
   - Password verification

### Step 4: Common Issues and Solutions

#### Issue 1: Database Connection Failed
**Symptoms:** "Database connection failed" error
**Solutions:**
- Ensure XAMPP MySQL service is running
- Check database credentials in `config.php`
- Verify database `dicom_app` exists
- Default credentials: username=`admin`, password=`G@ngstar36`

#### Issue 2: Users Table Missing
**Symptoms:** "Users table does not exist" error
**Solutions:**
- Run `setup_database.php` to create the schema
- Or manually import `db.sql` into your MySQL database

#### Issue 3: Session Issues
**Symptoms:** Login works but user gets logged out immediately
**Solutions:**
- Check if session directory is writable
- Verify session configuration in `config.php`
- Try clearing browser cookies and cache

#### Issue 4: CSRF Token Issues
**Symptoms:** "Security token validation failed" error
**Solutions:**
- Ensure `lib/csrf.php` file exists
- Check if sessions are starting properly
- Verify CSRF token is included in login form

### Step 5: Default Login Credentials

After running the setup, you can log in with:

| Username | Password | Role |
|----------|----------|------|
| admin | Admin@123 | Admin |
| doctor1 | Admin@123 | Doctor |
| uploader1 | Admin@123 | Uploader |

### Step 6: Manual Database Check

If you prefer to check the database manually:

1. Open phpMyAdmin: `http://localhost/phpmyadmin`
2. Select the `dicom_app` database
3. Check the `users` table
4. Verify users exist with correct password hashes

### Step 7: File Permissions

Ensure these files are readable by your web server:
- `config.php`
- `lib/auth.php`
- `lib/db.php`
- `lib/csrf.php`

### Step 8: XAMPP Configuration

Make sure XAMPP is properly configured:
1. Apache service is running
2. MySQL service is running
3. PHP is enabled
4. File is accessible via `http://localhost/dicom_app/`

### Step 9: Browser Issues

If login still doesn't work:
1. Clear browser cache and cookies
2. Try incognito/private browsing mode
3. Check browser console for JavaScript errors
4. Verify no browser extensions are interfering

### Step 10: Contact Support

If none of the above steps resolve the issue:
1. Check the error logs in XAMPP
2. Note any specific error messages
3. Provide the output from debug scripts

## Quick Fix Commands

If you have command line access:

```bash
# Check if MySQL is running
netstat -an | findstr 3306

# Check if Apache is running
netstat -an | findstr 80

# Test PHP
php -v
```

## Files Modified to Fix Login Issues

1. **login.php** - Added CSRF token field and improved error handling
2. **config.php** - Updated session configuration for XAMPP compatibility
3. **setup_database.php** - Created to ensure proper database setup
4. **test_session.php** - Created to test session and authentication
5. **debug_login.php** - Created for comprehensive debugging

## Next Steps

After following this guide:
1. Try logging in with the default credentials
2. If successful, you should be redirected to the appropriate dashboard
3. If still having issues, run the debug scripts and check the output
4. Consider checking XAMPP error logs for additional information
