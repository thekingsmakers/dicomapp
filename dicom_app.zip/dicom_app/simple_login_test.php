<?php
declare(strict_types=1);

require_once __DIR__ . '/config.php';
require_once __DIR__ . '/lib/auth.php';

echo "<h2>Simple Login Test</h2>";

// Start session
if (session_status() !== PHP_SESSION_ACTIVE) {
    session_start();
}

echo "<h3>Current Session Info:</h3>";
echo "Session ID: " . session_id() . "<br>";
echo "Session status: " . session_status() . "<br>";

// Check if user is already logged in
$currentUser = current_user();
if ($currentUser) {
    echo "<h3>Already Logged In:</h3>";
    echo "User: " . $currentUser['username'] . "<br>";
    echo "Role: " . $currentUser['role'] . "<br>";
    echo "<a href='dashboard_{$currentUser['role']}.php'>Go to Dashboard</a><br>";
    echo "<a href='logout.php'>Logout</a><br>";
    exit;
}

// Handle login attempt
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';
    
    echo "<h3>Login Attempt:</h3>";
    echo "Username: " . htmlspecialchars($username) . "<br>";
    
    if (empty($username) || empty($password)) {
        echo "❌ Username or password is empty<br>";
    } else {
        try {
            // Test database connection
            require_once __DIR__ . '/lib/db.php';
            $pdo = db();
            echo "✅ Database connected<br>";
            
            // Check if user exists
            $stmt = $pdo->prepare("SELECT id, username, password_hash, role FROM users WHERE username = ?");
            $stmt->execute([$username]);
            $user = $stmt->fetch();
            
            if ($user) {
                echo "✅ User found<br>";
                
                // Verify password
                if (password_verify($password, $user['password_hash'])) {
                    echo "✅ Password correct<br>";
                    
                    // Manually set session (bypass attempt_login function)
                    $_SESSION['user'] = [
                        'id' => (int)$user['id'],
                        'username' => $user['username'],
                        'role' => $user['role'],
                    ];
                    
                    echo "✅ Session set manually<br>";
                    echo "Session data: " . json_encode($_SESSION['user']) . "<br>";
                    
                    // Test redirect
                    $dashboard_url = 'dashboard_' . $user['role'] . '.php';
                    echo "Dashboard URL: " . $dashboard_url . "<br>";
                    
                    if (file_exists($dashboard_url)) {
                        echo "✅ Dashboard file exists<br>";
                        echo "<strong>Attempting redirect...</strong><br>";
                        
                        // Force output before redirect
                        ob_flush();
                        flush();
                        
                        // Try redirect
                        header('Location: ' . $dashboard_url);
                        exit;
                    } else {
                        echo "❌ Dashboard file not found: " . $dashboard_url . "<br>";
                        echo "<a href='{$dashboard_url}'>Try manual link</a><br>";
                    }
                } else {
                    echo "❌ Password incorrect<br>";
                }
            } else {
                echo "❌ User not found<br>";
            }
        } catch (Exception $e) {
            echo "❌ Error: " . $e->getMessage() . "<br>";
        }
    }
}

echo "<h3>Test Login Form:</h3>";
?>
<form method="POST" style="border: 1px solid #ccc; padding: 20px; margin: 20px 0;">
    <div>
        <label>Username: <input type="text" name="username" value="admin" required></label>
    </div>
    <div>
        <label>Password: <input type="password" name="password" value="Admin@123" required></label>
    </div>
    <div>
        <button type="submit">Login</button>
    </div>
</form>

<p><a href="setup_database.php">Setup Database</a> | <a href="login.php">Main Login</a></p>
