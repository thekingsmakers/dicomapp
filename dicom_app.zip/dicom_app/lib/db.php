<?php
declare(strict_types=1);

require_once __DIR__ . '/../config.php';

/**
 * Returns a shared PDO instance.
 */
function db(): PDO
{
    static $pdo = null;
    if ($pdo instanceof PDO) {
        return $pdo;
    }

    global $DB_DSN, $DB_USER, $DB_PASS;
    $options = [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES => false,
    ];
    $pdo = new PDO($DB_DSN, $DB_USER, $DB_PASS, $options);
    return $pdo;
}


