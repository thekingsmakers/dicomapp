<?php
declare(strict_types=1);

/**
 * Validate MRN: allow alphanumeric, dash, underscore, 1-64 chars
 */
function validate_mrn(string $mrn): bool
{
    return (bool)preg_match('/^[A-Za-z0-9_-]{1,64}$/', $mrn);
}

/**
 * Validate a DICOM file signature: checks magic 'DICM' at offset 128.
 */
function validate_dicom_signature(string $filePath): bool
{
    if (!is_file($filePath)) {
        return false;
    }
    $fh = @fopen($filePath, 'rb');
    if (!$fh) {
        return false;
    }
    try {
        if (fseek($fh, 128) !== 0) {
            return false;
        }
        $magic = fread($fh, 4);
        return $magic === 'DICM';
    } finally {
        fclose($fh);
    }
}


