<?php
declare(strict_types=1);
require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../lib/auth.php';
send_security_headers();
ensure_session_started();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>DICOM App</title>
    <link rel="stylesheet" href="<?= htmlspecialchars(app_url('css/styles.css')) ?>">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <script src="<?= htmlspecialchars(app_url('js/app.js')) ?>" defer></script>
    <script src="<?= htmlspecialchars(app_url('js/upload.js')) ?>" defer></script>
</head>
<body>
<nav class="top-nav">
    <a href="<?= htmlspecialchars(app_url('login.php')) ?>" class="brand">DICOM App</a>
    
    <?php if (current_user()): $u = current_user(); ?>
        <div class="user-info">
            <span class="user-role"><?= htmlspecialchars(ucfirst($u['role'])) ?></span>
            <span>Welcome, <?= htmlspecialchars($u['username']) ?></span>
            <a href="<?= htmlspecialchars(app_url('logout.php')) ?>" class="btn btn-sm">
                <i class="fas fa-sign-out-alt"></i> Logout
            </a>
        </div>
    <?php endif; ?>
</nav>
<main class="container">

